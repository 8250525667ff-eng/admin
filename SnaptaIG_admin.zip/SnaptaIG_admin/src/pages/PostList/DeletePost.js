import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import './style.css'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import { HiOutlineTrash } from "react-icons/hi2";

function DeletePost({ open, handleClose, handleDelete, postId }) {

    const {data,error,postData} = useApiPost();


    const handleDeletePost = async () => {
  try {
    const response = await postData("/delete_post", { post_id: postId });
    handleClose();
    if (response?.status === "success") {
      toast.success("Post Deleted Successfully!");
      handleDelete();
    }

  } catch (error) {
    console.error("Delete post error:", error);
    toast.error("Something went wrong while deleting the post.");
  }
};


    console.log("PostId",postId)

    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="custom-dialog" >
            <DialogContent className="flex flex-col items-center text-center dark:bg-primary">
                {/* Delete Icon */}
                <div className="flex justify-center p-2 rounded-full 2xl:p-4 bg-opacityGradient dark:bg-purple-300">
                    {/* <img src={Delete} alt="delete" className="w-9 h-9" /> */}
                    <HiOutlineTrash  className="text-header" style={{ fontSize: "35px"}}/>
                </div>

                {/* Confirmation Text */}
                <h2 className="text-xl font-poppins text-[#000000] dark:text-darkText mt-4">Are you sure you want to delete?</h2>
            </DialogContent>
            
            <DialogContent className="flex justify-center gap-4 pb-4 dark:bg-primary">
                <div className="flex justify-center gap-3">
                    <button className="px-20 py-2 rounded-lg border border-header text-[#3A3333] dark:text-darkText font-medium" onClick={handleClose}>
                        Cancel
                    </button>
                    <button onClick={handleDeletePost} className="px-20 py-2 font-medium text-white rounded-lg bg-button-gradient">
                        Delete
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default DeletePost;
