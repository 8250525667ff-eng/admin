const RoundedShimmer = () => {
  return (
    <div className="w-full h-full bg-gray-300 rounded-full animate-pulse" />
  );
};

export default RoundedShimmer;