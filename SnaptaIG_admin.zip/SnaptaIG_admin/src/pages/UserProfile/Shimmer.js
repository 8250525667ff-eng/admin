// components/Shimmer.js
// const Shimmer = () => {
//     return (
//       <div className="w-full h-full bg-gray-300 rounded-md animate-pulse" />
//     );
//   };
  
//   export default Shimmer;
  
const Shimmer = () => {
  return (
    <div className="w-full h-full bg-gray-300 rounded-md animate-pulse" />
  );
};

export default Shimmer;