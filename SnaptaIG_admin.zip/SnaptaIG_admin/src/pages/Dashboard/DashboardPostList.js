import React, { useEffect, useState } from "react";
import Loader from "../../assets/Loader.gif";
import useApiPost from "../hooks/postData";
import { Link } from "react-router-dom";
import formatDate from "../../components/formatDate";
import formatTime from "../../components/formatTime";
import NoData from "../../assets/NoData.png";

function PostList() {
  const [isLoading, setIsLoading] = useState(false);
  const { data, error, postData, refetch,loading } = useApiPost();
  const handleGetPostList = async () => {
    try {
      const response = await postData("/get_all_latest_post_pagination");
    } catch (error) {}
  };

  useEffect(() => {
    handleGetPostList();
  }, [refetch]);

  const AllPostList = data?.rescent_post;
  return (
    <>
      <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg overflow-x-auto w-full 2xl:w-[62%] xl:w-[100%]">
        <div className="xl:overflow-x-auto lg:overflow-x-auto 2xl:overflow-hidden min-w-[1200px] md:min-w-[1200px] lg:min-w-[0px] sm:min-w-[0px]">
          <div className="min-w-max">
            {/* Title and View All */}
            <div className="flex items-center justify-between px-4 mt-4 mb-4">
              <h2 className="text-[#000000] font-poppins text-base font-semibold dark:text-darkText">
                Post Summary
              </h2>
              <Link to="/post-list">
                <p className="cursor-pointer text-[#484848] text-sm underline font-poppins">
                  View All
                </p>
              </Link>
            </div>

            {/* Table */}
            <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg overflow-hidden mx-4 my-4">
              {/* Table Header */}
              <div className="flex w-full px-4 py-2 text-left border-b dark:border-[#1F1F1F] bg-header1 dark:bg-darkHeader">
                <div className="w-[8%] text-headerText font-semibold font-poppins text-sm">
                  S.L
                </div>

                <div className="w-[13%] text-headerText font-semibold font-poppins text-sm flex items-center gap-2">
                  POST IMAGE
                </div>

                {/* USERNAME COLUMN */}
                <div className="w-[30%] text-headerText font-semibold font-poppins text-sm flex items-center gap-2">
                  USERNAME
                </div>

                {/* DATE/TIME COLUMN */}
                <div className="w-[18%] text-headerText font-semibold font-poppins text-sm flex items-center gap-2">
                  POSTED DATE/TIME
                </div>

                {/* LIKES COLUMN */}
                <div className="w-[12%] text-headerText font-semibold font-poppins text-sm flex items-center gap-2">
                  LIKES
                </div>

                {/* COMMENTS COLUMN */}
                <div className="w-[10%] text-headerText font-semibold font-poppins text-sm flex items-center gap-2">
                  COMMENTS
                </div>
              </div>

              {/* Table Data */}
              {loading ? 
              (<>
               <div className="flex flex-col justify-center py-40 place-items-center">
                <img src={Loader} alt="loader" height={50} width={50}/>
               </div>
              </>) : 
              (<>
               {AllPostList?.length > 0 ? (
                <>
                  {AllPostList?.slice(0, 5).map((post, index) => (
                    <div
                      key={post.id}
                      className={`${
                        index % 2 === 0
                          ? "bg-white dark:bg-primary"
                          : "bg-[#00162e0a] dark:bg-primary"
                      } flex items-center px-4 py-3 dark:border-[#1F1F1F] border-b last:border-0`}
                    >
                      {/* Serial Number */}
                      <div className="w-[8%] text-[#000000] dark:text-darkText font-poppins text-sm">
                        {index + 1}
                      </div>

                      {/* Post Image */}
                      <div
                        className={`w-[13%] relative cursor-pointer  ${
                          post.post_images.length > 1
                        }`}
                      >
                        <img
                          src={post.post_images[0]?.url}
                          className="object-cover rounded-lg w-14 h-14"
                        />
                        {/* more images div */}
                        {post.post_images.length > 1 && (
                          <div className="absolute inset-0 bg-[#000000] bg-opacity-40 justify-center w-14 h-14 rounded-lg font-poppins text-[#ffffff] py-3.5 px-4">
                            +{post.post_images.length - 1}
                          </div>
                        )}
                      </div>

                      {/* Username */}
                      <div className="w-[30%] flex gap-2 items-center">
                        <img
                          src={post.profile_pic}
                          className="w-12 h-12 rounded-full"
                        />
                        <div>
                          <h2 className="text-[#00162e] font-poppins text-sm font-semibold cursor-pointer dark:text-darkText">
                            {post.username}
                          </h2>
                          <p className="text-xs text-[#777777] font-poppins">
                            {post.email}
                          </p>
                        </div>
                      </div>

                      {/* Date and Time */}
                      <div className="w-[18%]">
                        <h2 className="text-[#00162e] font-poppins text-sm dark:text-darkText">
                          {formatDate(post.created_at)}
                        </h2>
                        <h2 className="text-[#7A7A7A] font-poppins text-xs">
                          {formatTime(post.created_at)}
                        </h2>
                      </div>

                      {/* Likes */}
                      <div className="w-[12%] text-[#3A3A3A] font-poppins text-sm dark:text-gray-500">
                        {post.total_likes}{" "}
                        {post.total_likes > 1 ? "Likes" : "Like"}
                      </div>

                      {/* Comments */}
                      <div className="w-[10%] text-[#3A3A3A] font-poppins text-sm dark:text-gray-500">
                        {post.total_comments}{" "}
                        {post.total_comments > 1 ? "Comments" : "Comment"}
                      </div>
                    </div>
                  ))}
                </>
              ) : (
                <>
                  <div className="flex flex-col justify-center py-28 place-items-center">
                    <img src={NoData} alt="no data" className="w-48" />
                    <h2 className="font-poppins text-[#000000] text-sm font-semibold">
                      Don't have any data to show
                    </h2>
                  </div>
                </>
              )}
              </>)}
              
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default PostList;
