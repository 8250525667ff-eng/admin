import React from 'react';
import { PieChart, ResponsiveContainer, Pie, Cell } from 'recharts';
import { useGetUserLoginQuery } from '../../../store/api/UserLoginDashboard';
import Cookies from 'js-cookie';
import Loader from '../../../assets/Loader.gif';

const COLORS = ['#D77960', '#6956E5', '#E6B47B', '#B8D3E7'];

function CustomerLogin() {
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: UserLogin, isLoading } = useGetUserLoginQuery({ token });

  const data = UserLogin ? [
    { name: "Email", value: UserLogin.total_email_login, percent: UserLogin.email_percentage },
    { name: "Mobile Number", value: UserLogin.total_mobile_login, percent: UserLogin.mobile_percentage },
    { name: "Gmail", value: UserLogin.total_gmail_login, percent: UserLogin.gmail_percentage },
    { name: "Apple", value: UserLogin.total_apple_login, percent: UserLogin.apple_percentage },
  ] : [];

  // if (isLoading) {
  //   return (
  //     <div className="border border-[#D1D5DB] rounded-lg p-4 w-full h-[440px] flex items-center justify-center">
  //       <img src={Loader} className="w-12 h-12" alt="Loading..." />
  //     </div>
  //   );
  // }

  if (!UserLogin || isLoading) {
  return (
    <div className="border border-[#D1D5DB] rounded-lg p-4 w-[45%] h-[480px] flex items-center justify-center">
      <img src={Loader} className="w-12 h-12" alt="Loading..." />
    </div>
  );
}
console.log("Total Count @#",UserLogin.total_count)
if (UserLogin.total_count === 0) {
  return (
    <div className="border border-[#D1D5DB] dark:border-[#1F1F1F] p-4 w-full 2xl:w-[45%] rounded-lg h-[480px]">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[#000000] text-base font-semibold font-poppins dark:text-darkText">User by Login</h2>
      </div>
      

      <div className="w-full h-[300px] md:h-[350px] flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={[{ name: "No Data", value: 1 }]}
              innerRadius={75}
              outerRadius={110}
              paddingAngle={2}
              dataKey="value"
              label={false}
            >
              <Cell fill="#E0E0E0" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="grid items-center justify-center grid-cols-2 gap-4 mt-6 md:flex-row sm:flex sm:flex-col lg:flex-row lg:flex 2xl:flex-row lg:gap-10">
        {data.map((entry, index) => (
          <div key={index} className="flex items-start gap-2">
            <div
              style={{
                width: 14,
                height: 14,
                backgroundColor: COLORS[index],
                marginTop: 4,
              }}
            />
            <div className="flex flex-col items-start">
              <span className="font-poppins text-[#727272] text-sm">{entry.name}</span>
              <span className="text-[#484848] font-poppins text-sm">0</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

  return (
    <div className="border border-[#D1D5DB] dark:border-[#1F1F1F] p-4 w-full 2xl:w-[45%] rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[#000000] text-base font-semibold font-poppins dark:text-darkText">User by Login</h2>
      </div>
      {isLoading ? 
      (<>
       <div className='h-[300px] md:h-[350px] w-[45%] flex items-center justify-center'>
        <img src={Loader} alt="loader" height={50} width={50}/>
       </div>
       </>) : 
      
      (<>
       {/* Pie Chart */}
      <div className="w-full h-[300px] md:h-[350px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <defs>
              <filter id="pie-shadow" x="-20%" y="-20%" width="200%" height="200%">
                <feDropShadow dx="0" dy="4" stdDeviation="10" floodColor="#452B7A" floodOpacity="0.2" />
              </filter>
            </defs>
            <Pie
              data={data}
              innerRadius={75}
              outerRadius={110}
              paddingAngle={2}
              dataKey="value"
              filter="url(#pie-shadow)"
              label={({ percent }) => `${percent}%`}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Custom Legend */}
      <div className="grid items-center justify-center grid-cols-2 gap-4 mt-6 md:flex-row sm:flex sm:flex-col lg:flex-row lg:flex 2xl:flex-row lg:gap-10">
        {data.map((entry, index) => (
          <div key={index} className="flex items-start gap-2">
            <div
              style={{
                width: 14,
                height: 14,
                backgroundColor: COLORS[index],
                marginTop: 4,
              }}
            />
            <div className="flex flex-col items-start">
              <span className="font-poppins text-[#727272] text-sm">{entry.name}</span>
              <span className="text-[#484848] font-poppins text-sm">{entry.percent}%</span>
            </div>
          </div>
        ))}
      </div>
      </>)}

      
    </div>
  );
}

export default CustomerLogin;
