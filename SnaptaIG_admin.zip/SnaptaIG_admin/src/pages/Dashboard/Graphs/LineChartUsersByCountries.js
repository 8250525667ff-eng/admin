import React, { useEffect } from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, Cell } from "recharts";
import Cookies from "js-cookie";
import { useGetCountryWiseUserQuery } from "../../../store/api/CountryWiseUserDashboard";
import Loader from "../../../assets/Loader.gif";
import { Link } from "react-router-dom";
import { WorldMap } from "react-svg-worldmap";
import { getCode } from "country-list"; // 🌍 for mapping country name → alpha-2
import { useTheme } from "../../../context/ThemeProvider";
import "./mapstyle.css";
import countries from "i18n-iso-countries";
import enLocale from "i18n-iso-countries/langs/en.json";

countries.registerLocale(enLocale);

const COLORS = ["#46BFDA", "#3DD0B7", "#F3CC5C", "#59A7FF"];

function UsersByCountry() {
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: countryData, isLoading } = useGetCountryWiseUserQuery({
    token,
  });

  const normalizeCountryName = (name = "") => {
    if (!name || typeof name !== "string") return null;

    const trimmed = name.trim();
    const code = countries.getAlpha2Code(trimmed, "en");

    if (!code) {
      console.warn(`Unmatched country: "${trimmed}"`);
      return null;
    }

    return code.toLowerCase(); // WorldMap requires lowercase
  };

  const chartData = (
    countryData?.data?.slice(0, 4).map((item) => ({
      country: item.country,
      users: item.total_users,
    })) || []
  ).sort((a, b) => b.users - a.users);

  // Map country names to Alpha-2 codes for WorldMap

  const mapData = (countryData?.data || [])
    .map((item) => {
      const code = normalizeCountryName(item.country);
      if (!code) return null;
      return {
        country: code,
        value: item.total_users,
      };
    })
    .filter(Boolean); // Remove null values

  const { theme } = useTheme();
  console.log("Theme!!! #2", mapData);

  if (isLoading) {
    return (
      <div className="border border-[#D1D5DB] rounded-lg p-4 w-full h-[440px] flex items-center justify-center">
        <img src={Loader} className="w-12 h-12" alt="Loading..." />
      </div>
    );
  }

  console.log("Code !!!", getCode("Russia"));

  const isDark = theme === "dark";
  console.log("Theme @#$12", theme);

  const barBgColor = isDark ? "#1F1F1F" : "#E5E7EB"; // background of the bar
  const countryTextColor = isDark ? "#E5E7EB" : "#4B5563"; // country name
  const userValueColor = isDark ? "#F9FAFB" : "#111827"; // value number
  console.log("Country Data @#12", countryData.data.length);

 

  return (
    <div className="border border-[#D1D5DB] dark:border-[#1F1F1F] dark:bg-primary p-4 w-full rounded-lg bg-white xl:w-[100%]">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[#000000] font-poppins text-base font-semibold dark:text-darkText">
          Users by Countries
        </h2>
        <Link to="/country-wise-users">
          <span className="cursor-pointer text-[#484848] text-sm underline font-poppins">
            View All
          </span>
        </Link>
      </div>

      <div className="flex flex-col gap-8 xl:flex-row dark:bg-transparent ">
        <div
          className={`overflow-x-auto 2xl:overflow-hidden ${
            isDark ? "bg-[#121212]" : "bg-white"
          }`}
        >
          <WorldMap
            color={isDark ? "#90caf9" : "#1976d2"} // Primary map fill
            backgroundColor={isDark ? "#121212" : "#ffffff"} // Map background
            valueSuffix="people"
            size="responsive"
            data={mapData}
            styleFunction={(context) => ({
              fill: context.countryValue
                ? isDark
                  ? "#8963D7"
                  : "#8963D7"
                : isDark
                ? "#424242"
                : "#e0e0e0",
              stroke: isDark ? "#eeeeee" : "#424242",
              strokeWidth: 1,
              cursor: "pointer",
            })}
          />
        </div>

        {/* Horizontal Bar Chart */}
        {/* Horizontal Bar Chart */}
{chartData.length > 0 ? (
  <div className="w-[100%] my-10 bg-white rounded-lg xl:w-1/2 dark:bg-primary">
    <div className="items-start gap-6 2xl:flex 2xl:flex-row">
      <div className=" w-full h-[150px] mt-10">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            layout="vertical"
            data={chartData}
            barCategoryGap={6}
            margin={{ top: 25, right: 72, left: 20, bottom: 25 }}
          >
            <XAxis type="number" hide />
            <Bar
              dataKey="users"
              background={{ fill: barBgColor, radius: [10, 10, 10, 10] }}
              radius={[10, 10, 10, 10]}
              label={({ x, y, width, height, value, index }) => {
                const country = chartData[index].country;
                const labelX = 700;

                return (
                  <g>
                    <text
                      x={x}
                      y={y - 6}
                      fontSize="12"
                      fill={countryTextColor}
                      fontFamily="Poppins"
                    >
                      {country}
                    </text>

                    <circle
                      cx={x + width}
                      cy={y + height / 2}
                      r={7}
                      fill={COLORS[index % COLORS.length]}
                      stroke="#fff"
                      strokeWidth={2}
                    />

                    <text
                      x={labelX}
                      y={y + height / 2 + 4}
                      textAnchor="start"
                      fontSize="12"
                      fill={userValueColor}
                      fontFamily="Poppins"
                    >
                      {value} Users
                    </text>
                  </g>
                );
              }}
            >
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  </div>
) : (
  <div className="w-[100%] my-10 py-44 bg-white rounded-lg xl:w-1/2 dark:bg-primary flex items-center justify-center h-[150px] mt-10">
    <p className="text-sm text-gray-500 font-poppins dark:text-gray-300">No data available</p>
  </div>
)}
      </div>
    </div>
  );
}

export default UsersByCountry;





