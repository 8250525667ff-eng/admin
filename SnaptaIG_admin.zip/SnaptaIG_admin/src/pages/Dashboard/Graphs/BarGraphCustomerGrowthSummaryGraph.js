import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import Calendar from "../../../assets/bar_calendar.png";
import ArrowDown from "../../../assets/bar_arrow.png";
import { useGetGrowthQuery } from "../../../store/api/GetUserByMonthDashboard";
import Cookies from 'js-cookie'
import Loader from '../../../assets/Loader.gif'
import { useTheme } from "../../../context/ThemeProvider";

function BarGraph() {

  const token = Cookies.get("Snapta_Admin_Token")
  const {data:BarData,isLoading} = useGetGrowthQuery({token:token})

  console.log("Data !!!",BarData)
  const theme = useTheme().theme
  console.log("Theme !!!",theme)

  const max = 20
  const monthMap = {
    January: "Jan",
    February: "Feb",
    March: "Mar",
    April: "Apr",
    May: "May",
    June: "Jun",
    July: "Jul",
    August: "Aug",
    September: "Sep",
    October: "Oct",
    November: "Nov",
    December: "Dec",
  };
  
  const currentMonth = new Date().toLocaleString("default", { month: "long" });
  console.log("Month !!",currentMonth)
  const data = BarData?.data?.map((d) => ({
    name: monthMap[d.month] || d.month, // convert to short form
    value: d.total,
    remaining: max - d.total,
    color: d.month === currentMonth ? "#8963D7" : "#59A7FF",
  }));

  if (isLoading || !BarData) {
    return (
      <div className="border border-[#D1D5DB] rounded-lg p-4 w-full h-[440px] flex items-center justify-center">
        <img src={Loader} className="w-12 h-12" alt="Loading..." />
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length > 0) {
      // Only show the actual value, not "remaining"
      const valueData = payload.find(p => p.dataKey === "value");
      return (
        <div className="px-3 py-2 bg-white border border-gray-200 rounded shadow-sm">
          <p className="text-sm text-gray-700 font-poppins">{label}</p>
          <p className="text-sm font-semibold text-black font-poppins">Users: {valueData?.value}</p>
        </div>
      );
    }
  
    return null;
  };
  console.log("Bar data @#12",BarData)

  return (
    <div className="border border-[#D1D5DB] dark:border-[#1F1F1F] rounded-lg p-4 w-full">
  {/* Wrap chart section */}
  <div className="overflow-x-auto lg:overflow-x-visible">
    <div className="min-w-[1020px] lg:min-w-0">
      {/* Chart Header */}
      <div className="flex justify-between">
        <h2 className="text-[#000000] font-poppins text-base font-semibold dark:text-darkText">
          User Growth Summary Graph
        </h2>
        <div className="flex items-center gap-2">
          <img src={Calendar} className="w-5 h-5" />
          <div className="flex items-center gap-2">
            <h2 className="font-poppins text-[#8C8C8C] text-base font-medium">2025</h2>
            <img src={ArrowDown} className="w-4 h-4 cursor-pointer" />
          </div>
        </div>
      </div>

      <p className="text-[#737373] font-poppins text-sm pb-12">
        Revealing risk and growth in investment
      </p>

      {/* Responsive Bar Chart */}
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={data}>
          <CartesianGrid vertical={false} />
          <XAxis dataKey="name" />
          <YAxis domain={[0, max]} axisLine={false} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(0, 0, 0, 0)" }} />
          <Bar dataKey="value" stackId="a" barSize={20} radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
          <Bar
            dataKey="remaining"
            stackId="a"
            fill={theme === "dark" ? "#333333" : "#F0F0F0"}
            barSize={20}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>
</div>

  );
}

export default BarGraph;






