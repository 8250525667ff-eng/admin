import React,{useEffect} from 'react'
import TotalUsers from './TotalUsers'
import TotalPosts from './TotalPosts'
import TotalReels from './TotalReels'
import TotalStories from './TotalStories'
import Searchbar from '../../components/Search'
import BarGraph from './Graphs/BarGraphCustomerGrowthSummaryGraph'
import PieChart from './Graphs/PieChartMediaAnalytics'
import CustomerLogin from './Graphs/PieChartUserLogin'
import UsersByCountry from './Graphs/LineChartUsersByCountries'
import PlatformActivity from './Graphs/PieChartPlatformActivity'
import UsersList from './DashboardUsersList'
import PostList from './DashboardPostList'
import HashtagList from './DashboardHashtagList'
import { useSelector } from 'react-redux'
import Cookies from 'js-cookie'
import { useNavigate } from 'react-router-dom'

function Dashboard() 
{
  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);
 
  
    return(
        <>
        <div className={` dark:bg-primary ${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
            <Searchbar />
        <div className='grid flex-col gap-4 px-4 py-8 xl:grid-cols-4 md:grid-cols-2 xl:px-6 xl:gap-8'>
            <div className=''>
                <TotalUsers />
            </div>
            <div className=''>
                <TotalPosts />
            </div>
            <div className=''>
                <TotalReels />
            </div>
            <div className=''>
                <TotalStories />
            </div>
          </div>

          {/* 2nd row */}
          <div className='flex flex-col w-full gap-4 px-6 2xl:flex-row 2xl:grid 2xl:grid-cols-[62%,37%]'>
            <BarGraph />
            <PieChart />
          </div>
          
          {/* 3rd row */}
          <div className='flex flex-col w-full gap-4 px-6 py-8 2xl:flex-row'>
            <CustomerLogin />
            <UsersList />
          </div>

          {/* 4th row */}
          <div className='flex flex-col w-full gap-4 px-6 2xl:flex-row'>
            <UsersByCountry  />
            {/* <PlatformActivity /> */}
          </div>

          {/* 5th row */} 
          <div className='flex flex-col w-full gap-4 px-6 py-8 2xl:flex-row'>
            <PostList />
            <HashtagList />
          </div>
        </div>
        </>
    )
}

export default Dashboard



