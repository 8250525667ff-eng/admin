import React, { useEffect, useState } from "react";
import Background from "../../assets/BackgroundImageAppInstallation.png";
import Logo from "../../assets/SnaptaLogo.png";
import Snapta from "../../assets/Snapta.png";
import LightVector from "../../assets/LightVector.png";
import InfoCircle from "../../assets/info-circle.png";
import GreenTick from "../../assets/GreenTick.png";
import LightStroke from "../../assets/LightStroke.png";
import axios from "axios";
import { RxCross2 } from "react-icons/rx";
import { Link } from "react-router-dom";

function Page1() {
  const [extensions, setExtensions] = useState();
  useEffect(() => {
    const fetchAdminDetails = async () => {
      try {
        const response = await axios.get(
          `${process.env.REACT_APP_API_URL}/check-extensions`
        );
        setExtensions(response.data);
      } catch (err) {
        console.error("Failed to fetch admin login details", err);
      }
    };

    fetchAdminDetails();
  }, []);

  const Extensions = extensions?.extensions;
  function handleSet() 
  {
    sessionStorage.setItem("show_varification_steps", true);
  }

  return (
    <>
      <div className="relative w-full h-screen">
        {/* Background Image */}
        <img
          src={Background}
          alt="Background"
          className="object-cover w-full h-full"
        />

        {/* Overlay Content */}
        <div className="absolute inset-0 flex flex-col">
          {/* Top Right Logo and Snapta */}
          <div className="flex justify-center p-4 sm:p-12 sm:justify-end">
            <div className="flex items-center gap-3">
              <img
                src={Logo}
                alt="Logo"
                width={40}
                height={40}
                className="w-10 h-10 2xl:w-12 2xl:h-12"
              />
              <img
                src={Snapta}
                alt="Snapta"
                className="pt-1 w-28"
                width={170}
                height={32}
              />
            </div>
          </div>

          {/* Center Title */}
          <div className="justify-center">
            <h2 className="text-[#000000] sm:text-4xl text-xl font-semibold font-poppins text-center">
              Snapta App Software Installation
            </h2>
            <p className="text-[#000000] font-poppins sm:text-base text-center pt-2">
              Please make sure the PHP extensions listed below are installed
            </p>
          </div>

          {/* No. of Steps */}
          <div className="flex justify-center py-3 sm:gap-3 place-items-center">
            <button
              className={`rounded-full px-5 py-2 bg-button-gradient text-[#FFFFFF] font-poppins`}
            >
              1
            </button>
            <img src={LightVector} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-opacityGradient text-opacityGradient font-poppins`}
            >
              2
            </button>
            <img src={LightStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-opacityGradient text-opacityGradient font-poppins`}
            >
              3
            </button>
            <img src={LightStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-opacityGradient text-opacityGradient font-poppins`}
            >
              4
            </button>
            <img src={LightStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-opacityGradient text-opacityGradient font-poppins`}
            >
              5
            </button>
          </div>

          {/* Centered Div */}
          <div className="flex justify-center py-6 w-fit sm:w-full">
            <div
              className="bg-[#FFFFFF] sm:w-[950px] w-fit rounded-md p-3"
              style={{ boxShadow: "8px 9px 55.9px 0px #00000033" }}
            >
              <div className="justify-between sm:flex">
                <h2 className="font-poppins text-[#000000] text-base flex flex-row ">
                  Step 1 :
                  <div className="flex flex-col">
                    <span className="font-poppins text-[#555555] text-base pl-1">
                      Required PHP Extensions
                    </span>
                    <span className="hidden pl-1 text-sm text-red-500 sm:block xl:text-sm 2xl:text-sm font-poppins">
                      Please make sure the PHP extensions listed below are
                      installed
                    </span>
                  </div>
                </h2>
                <span className="block text-sm text-red-500 sm:hidden xl:text-sm 2xl:text-sm font-poppins">
                  Please make sure the PHP extensions listed below are installed
                </span>

                <div className="flex gap-1 place-items-center">
                  <a
                    target="_blank"
                    href="https://document.snapta.online/"
                    className="font-poppins text-[#435CFF] underline text-xs cursor-pointer"
                  >
                    Read documentation
                  </a>
                  <img src={InfoCircle} className="w-3 h-3" />
                </div>
              </div>

              <div
                className="sm:p-4"
                style={{ boxShadow: "2px 4px 14.4px 0px #0000000F" }}
              >
                <h2 className="font-poppins text-[#000000] text-opacity-[63%] text-center pt-4 pb-4 font-semibold">
                  Check & Verify File Permissions
                </h2>

                {/* Scrollable table wrapper */}
                <div className="overflow-x-auto">
                  <table className="min-w-full border border-collapse border-[#452B7A] border-opacity-10">
                    <tbody>
                      {/* Email Row */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 sm:w-[25%] w-[10%] text-[#452B7A] text-center font-poppins border bg-opacityGradient border-[#452B7A] border-opacity-10">
                          Extension
                        </td>
                        <td className="px-4 py-2 sm:w-[25%] w-[10%] text-[#452B7A] bg-opacityGradient font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Status
                        </td>
                        <td className="px-4 py-2 sm:w-[25%] w-[10%] text-[#452B7A] bg-opacityGradient font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Extension
                        </td>
                        <td className="px-4 py-2 sm:w-[25%] w-[10%] text-[#452B7A] bg-opacityGradient font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Status
                        </td>
                      </tr>

                      {/* Row 2 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center text-sm font-poppins border border-[#452B7A] border-opacity-10">
                          PHP>=8.1
                        </td>
                        <td className="px-4 py-2 w-[25%] place-items-center text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {extensions?.required_php_version === "8.1" ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          PHP Version
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {extensions?.php_version_status === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                      </tr>

                      {/* Row 3 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center font-poppins border text-sm border-[#452B7A] border-opacity-10">
                          Bcmath
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.bcmath === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Openssl
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.openssl === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                      </tr>

                      {/* Row 4 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center font-poppins border text-sm border-[#452B7A] border-opacity-10">
                          Ctype
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.ctype === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Pdo
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.pdo === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                      </tr>

                      {/* Row 5 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center font-poppins text-sm border border-[#452B7A] border-opacity-10">
                          Fileinfo
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.fileinfo === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Tokenizer
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.tokenizer === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}

                          {/* <img src={Extensions?.tokenizer === true ? GreenTick : <RxCross2 className='text-red-500'/>} className='w-4 h-4'/> */}
                        </td>
                      </tr>

                      {/* Row 6 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center text-sm font-poppins border border-[#452B7A] border-opacity-10">
                          Json
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {/* <img src={Extensions?.json === true ? GreenTick : <RxCross2 className='text-red-500'/>} className='w-4 h-4'/> */}
                          {Extensions?.json === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10">
                          Xml
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.xml === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                      </tr>

                      {/* Row 7 */}
                      <tr className="border border-[#452B7A] border-opacity-10">
                        <td className="px-4 py-2 w-[25%] text-center font-poppins border text-sm border-[#452B7A] border-opacity-10">
                          Mbstring
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {Extensions?.mbstring === true ? (
                            <img src={GreenTick} className="w-4 h-4" />
                          ) : (
                            <RxCross2 className="text-red-500" />
                          )}
                        </td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] font-poppins text-center border border-[#452B7A] border-opacity-10"></td>
                        <td className="px-4 py-2 w-[25%] text-[#000000] place-items-center font-poppins text-center border border-[#452B7A] border-opacity-10">
                          {/* <img src={GreenTick} className='w-4 h-4'/> */}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Next button */}
              <div className="flex justify-center py-3">
                <Link to="/snapta-install-2">
                  <button
                    className={`px-20 py-3 font-medium text-white rounded-xl ${
                      extensions?.all_valid === true
                        ? "bg-button-gradient"
                        : "bg-opacityGradient cursor-not-allowed"
                    }`} 
                    onClick={handleSet}
                  >
                    Next
                  </button>
                </Link>
              </div>
            </div>
          </div>
          {/* Divider */}
          <div className="flex justify-center py-2">
            <div className="bg-[#CCCCCC] h-[2px] w-[950px]"></div>
          </div>

          {/* Logo */}
          <div className="sm:flex justify-between w-full max-w-[970px] mx-auto px-4 pb-4 sm:pb-0">
            <div className="flex items-center gap-2">
              <img src={Logo} alt="Logo" className="w-5 h-5 sm:w-7 sm:h-7" />
              <img src={Snapta} alt="Snapta" className="w-16 pt-1 sm:w-20" />
            </div>

            <p className="font-poppins text-[#535353] text-sm">
              @2025 | All rights reserved by{" "}
              <a
                className="text-[#2A2A2A] underline font-semibold cursor-pointer"
                href="https://primocys.com/"
                target="_blank"
              >
                Primocys
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Page1;
