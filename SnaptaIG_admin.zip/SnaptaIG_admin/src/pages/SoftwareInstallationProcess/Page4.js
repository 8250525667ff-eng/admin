import React, { useState, useEffect } from "react";
import Background from "../../assets/BackgroundImageAppInstallation.png";
import Logo from "../../assets/SnaptaLogo.png";
import Snapta from "../../assets/Snapta.png";
import LightVector from "../../assets/LightVector.png";
import InfoCircle from "../../assets/info-circle.png";
import Info from "../../assets/info-circle2.png";
import DarkStroke from "../../assets/DarkStroke.png";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { ClipLoader } from "react-spinners";

function Page3() {
  const navigate = useNavigate();
  const token = Cookies.get("Snapta_Admin_Token");
  const [isEdited, setIsEdited] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [nextLoading,setNextLoading] = useState(false);

  const [formData, setFormData] = useState({
    aws_access_key_id: "",
    aws_secret_access_key: "",
    aws_bucket: "",
    aws_url: "",
  });

  useEffect(() => {
    setIsLoading(true)
    const fetchSavedConfiguration = async () => {
      try {
        const response = await axios.post(
          `${process.env.REACT_APP_API_URL}/save-bucket`
        );
        const config = response.data.updated_values;
        setFormData({
          aws_access_key_id: config.AWS_ACCESS_KEY_ID || "",
          aws_secret_access_key: config.AWS_SECRET_ACCESS_KEY || "",
          aws_bucket: config.AWS_BUCKET || "",
          aws_url: config.AWS_URL || "",
        });
      } catch (error) {
        console.error("Failed to fetch saved configuration:", error);
      } finally{
        setIsLoading(false)
      }
    };

    fetchSavedConfiguration();
  }, []);

  const handleNext = async () => {
    setNextLoading(true)
    try {
      const formDataToUpload = new FormData();
      formDataToUpload.append("app_url", formData.aws_access_key_id);
      formDataToUpload.append("db_database", formData.aws_secret_access_key);
      formDataToUpload.append("db_username", formData.aws_bucket);
      formDataToUpload.append("db_password", formData.aws_url);

      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/save-configuration`,
        formDataToUpload,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      toast.success("Configuration saved successfully!");
      setIsEdited(false);
      navigate("/snapta-install-4");
    } catch (error) {
      toast.error("Failed to save configuration.");
      console.error("Error saving configuration:", error);
    } finally{
      setNextLoading(false)
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setIsEdited(true);
  };

  return (
    <>
      <div className="relative w-full h-screen">
        {/* Background Image */}
        <img
          src={Background}
          alt="Background"
          className="object-cover w-full h-full"
        />

        {/* Overlay Content */}
        <div className="absolute inset-0 flex flex-col">
          {/* Top Right Logo and Snapta */}
          <div className="flex justify-center p-12 sm:justify-end">
            <div className="flex items-center gap-3">
              <img
                src={Logo}
                alt="Logo"
                width={40}
                height={40}
                className="w-10 h-10 2xl:w-12 2xl:h-12"
              />
              <img
                src={Snapta}
                alt="Snapta"
                className="pt-1 w-28"
                width={170}
                height={32}
              />
            </div>
          </div>

          {/* Center Title */}
          <div className="justify-center">
            <h2 className="text-[#000000] sm:text-4xl text-xl font-semibold font-poppins text-center">
              Snapta App Software Installation
            </h2>
            <p className="text-[#000000] font-poppins sm:text-base text-center pt-2">
              Please make sure the PHP extensions listed below are installed
            </p>
          </div>

          {/* No. of Steps */}
          <div className="flex justify-center py-3 sm:gap-3 place-items-center">
            <button
              className={`rounded-full px-5 py-2 bg-button-gradient text-[#FFFFFF] font-poppins`}
            >
              1
            </button>
            <img src={DarkStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-button-gradient text-[#FFFFFF] font-poppins`}
            >
              2
            </button>
            <img src={DarkStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-button-gradient text-[#FFFFFF] font-poppins`}
            >
              3
            </button>
            <img src={DarkStroke} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-button-gradient text-[#FFFFFF] font-poppins`}
            >
              4
            </button>
            <img src={LightVector} className="w-16" />
            <button
              className={`rounded-full px-4 py-2 bg-opacityGradient text-opacityGradient font-poppins`}
            >
              5
            </button>
          </div>

          {/* Centered Div */}

          <div className="flex justify-center w-full py-6">
            <div
              className="bg-[#FFFFFF] w-[950px] rounded-md sm:p-6 p-4"
              style={{ boxShadow: "8px 9px 55.9px 0px #00000033" }}
            >
              <div className="justify-between sm:flex">
                <h2 className="font-poppins text-[#000000] text-base flex flex-row">
                  Step 4 :
                  <div className="flex flex-col">
                    <span className="font-poppins text-[#555555] text-base pl-1">
                      Add AWS Information
                    </span>
                    <span className="hidden pl-1 text-sm text-red-500 sm:block xl:text-sm 2xl:text-sm font-poppins">
                      This step is necessary when you are setting up the aws
                      account for S3 bucket, or else you can skip
                    </span>
                  </div>
                </h2>
                <span className="block text-sm text-red-500 sm:hidden xl:text-sm 2xl:text-sm font-poppins sm:pl-1">
                  If you have entered the fields in env file then you can skip
                  this step
                </span>
                <div className="flex gap-1 pt-2 place-items-center sm:pt-0">
                  <a
                    target="_blank"
                    href="https://document.snapta.online/"
                    className="font-poppins text-[#435CFF] underline text-xs cursor-pointer"
                  >
                    Read documentation
                  </a>

                  <img src={InfoCircle} className="w-3 h-3" />
                </div>
              </div>

              {/* ==================== */}

              {/* ==================== */}

              {/* Username and purchase code */}
              {isLoading ? (<>
               <div className="flex justify-center py-24 place-items-center">
                 <ClipLoader
              loading={isLoading}
              size={20}
              aria-label="Loading Spinner"
              data-testid="loader"
              color="#452B7A"
            />
              </div>
              </>) : (<>
               <div
                className="bg-[#FFFFFF] sm:mx-12 mt-10 rounded-md p-6"
                style={{ boxShadow: "8px 9px 55.9px 0px #00000033" }}
              >
                <div className="gap-4 sm:flex">
                  {/* Database Name */}
                  <div className="sm:w-[50%]">
                    <div className="flex gap-1 pb-2 place-items-center">
                      <label className="font-poppins text-sm text-[#000000] font-semibold">
                        Access Key
                      </label>
                      <div className="relative inline-block group">
                        <img
                          src={Info}
                          className="w-3 h-3 cursor-pointer"
                          alt="info"
                        />

                        <div className="absolute z-10 hidden max-w-xs mt-2 group-hover:block w-max">
                          {/* Arrow */}
                          <div className="w-2 h-2 rotate-45 bg-[#EFEFEF]-mb-1"></div>

                          {/* Tooltip box */}
                          <div className="bg-[#EFEFEF] p-2 border border-[#EFEFEF] rounded shadow-lg">
                            <p className="font-poppins text-[#000000] text-xs break-words">
                              Your AWS IAM user's public access key used to
                              authenticate API requests.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <input
                      value={formData.aws_access_key_id}
                      onChange={(e) =>
                        handleChange("DB_DATABASE", e.target.value)
                      }
                      placeholder="access_key"
                      type="text"
                      className="border 2xl:py-4 border-[#452B7A] text-sm pl-4 w-full placeholder:text-xs placeholder:text-[#989898] focus:outline-none focus:ring-1 focus:ring-[#452B7A] border-opacity-10 text-[#000000] py-3 font-poppins rounded-md"
                    />
                  </div>

                  {/* Database Username */}
                  <div className="sm:w-[50%] pt-4 sm:pt-0">
                    <div className="flex gap-1 pb-2 place-items-center">
                      <label className="font-poppins text-sm text-[#000000] font-semibold">
                        Secret Access Key
                      </label>
                      <div className="relative inline-block group">
                        <img
                          src={Info}
                          className="w-3 h-3 cursor-pointer"
                          alt="info"
                        />

                        <div className="absolute z-10 hidden max-w-xs mt-2 group-hover:block w-max">
                          {/* Arrow */}
                          <div className="w-2 h-2 rotate-45 bg-[#EFEFEF]-mb-1"></div>

                          {/* Tooltip box */}
                          <div className="bg-[#EFEFEF] p-2 border border-[#EFEFEF] rounded shadow-lg">
                            <p className="font-poppins text-[#000000] text-xs break-words">
                              The private key paired with your Access Key ID —
                              keep this secret and never expose it in frontend.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <input
                      value={formData.aws_secret_access_key}
                      onChange={(e) =>
                        handleChange("DB_USERNAME", e.target.value)
                      }
                      placeholder="secret_access_key"
                      type="text"
                      className="border 2xl:py-4 border-[#452B7A] text-sm pl-4 w-full placeholder:text-xs placeholder:text-[#989898] focus:outline-none focus:ring-1 focus:ring-[#452B7A] border-opacity-10 text-[#000000] py-3 font-poppins rounded-md"
                    />
                  </div>
                </div>

                {/* Database Password */}
                <div className="gap-4 sm:flex">
                  <div className="sm:w-[50%] pt-4">
                    <div className="flex gap-1 pb-2 place-items-center">
                      <label className="font-poppins text-sm text-[#000000] font-semibold">
                        Bucket Name
                      </label>
                      <div className="relative inline-block group">
                        <img
                          src={Info}
                          className="w-3 h-3 cursor-pointer"
                          alt="info"
                        />
                        {/* Tooltip container (shown on hover) */}

                        <div className="absolute z-10 hidden max-w-xs mt-2 group-hover:block w-max">
                          {/* Arrow */}
                          <div className="w-2 h-2 rotate-45 bg-[#EFEFEF]-mb-1"></div>

                          {/* Tooltip box */}
                          <div className="bg-[#EFEFEF] p-2 border border-[#EFEFEF] rounded shadow-lg">
                            <p className="font-poppins text-[#000000] text-xs break-words">
                              The name of your S3 bucket — a globally unique
                              container for your files.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <input
                      value={formData.aws_bucket}
                      onChange={(e) =>
                        handleChange("DB_PASSWORD", e.target.value)
                      }
                      placeholder="bucket_name"
                      type="text"
                      className="border 2xl:py-4 border-[#452B7A] text-sm pl-4 w-full placeholder:text-xs placeholder:text-[#989898] focus:outline-none focus:ring-1 focus:ring-[#452B7A] border-opacity-10 text-[#000000] py-3 font-poppins rounded-md"
                    />
                  </div>

                  {/* Application URL */}
                  <div className="sm:w-[50%]  pt-4">
                    <div className="flex gap-1 pb-2 place-items-center">
                      <label className="font-poppins text-sm text-[#000000] font-semibold">
                        S3 Bucket URL
                      </label>
                      <div className="relative inline-block group">
                        <img
                          src={Info}
                          className="w-3 h-3 cursor-pointer"
                          alt="info"
                        />
                        {/* Tooltip container (shown on hover) */}
                        <div className="absolute z-10 hidden max-w-xs mt-2 group-hover:block w-max">
                          {/* Arrow */}
                          <div className="w-2 h-2 rotate-45 bg-[#EFEFEF]-mb-1"></div>

                          {/* Tooltip box */}
                          <div className="bg-[#EFEFEF] p-2 border border-[#EFEFEF] rounded shadow-lg">
                            <p className="font-poppins text-[#000000] text-xs break-words">
                              The base URL used to access your S3 objects via
                              the internet (unless restricted by permissions).
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <input
                      value={formData.aws_url}
                      onChange={(e) => handleChange("APP_URL", e.target.value)}
                      placeholder="Ex : https://yourdomain.com"
                      type="text"
                      className="border 2xl:py-4 border-[#452B7A] text-sm pl-4 w-full placeholder:text-[#989898] placeholder:text-xs focus:outline-none focus:ring-1 focus:ring-[#452B7A] border-opacity-10 text-[#000000] py-3 font-poppins rounded-md"
                    />
                  </div>

                  {/* ============================================ */}

                  {/*  */}
                </div>
              </div>
              </>)}
              
              
              {/* Next button */}
              <div className="flex justify-center pt-5">
                <div className="flex gap-4">
                  {/* Skip button */}
                  <Link to="/snapta-install-5">
                    <button
                      className={`px-20 py-3 font-medium text-white rounded-xl bg-button-gradient`}
                    >
                      Skip
                    </button>
                  </Link>

                  {/* Next Button */}
                  <button
                    onClick={handleNext}
                    className={`w-[200px] py-3 font-medium text-white rounded-xl ${
                      isEdited ? "bg-button-gradient" : "bg-opacityGradient"
                    }`}
                  > 
                  {nextLoading ? (<>
                   <ClipLoader
              loading={isLoading}
              size={20}
              aria-label="Loading Spinner"
              data-testid="loader"
              color="#452B7A"
            />
                  </>) : (<>
                   Next
                  </>)}
                  </button>
                </div>
              </div>
            </div>
          </div>
          {/* Divider */}
          <div className="flex justify-center py-2">
            <div className="bg-[#CCCCCC] h-[2px] w-[950px]"></div>
          </div>

          {/* Logo */}
          <div className="sm:flex justify-between w-full max-w-[970px] mx-auto px-4 pb-4 sm:pb-0">
            <div className="flex items-center gap-2">
              <img src={Logo} alt="Logo" className="w-5 h-5 sm:w-7 sm:h-7" />
              <img src={Snapta} alt="Snapta" className="w-16 pt-1 sm:w-20" />
            </div>

            <p className="font-poppins text-[#535353] text-sm">
              @2025 | All rights reserved by{" "}
              <a
                className="text-[#2A2A2A] underline font-semibold cursor-pointer"
                href="https://primocys.com/"
                target="_blank"
              >
                Primocys
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Page3;
