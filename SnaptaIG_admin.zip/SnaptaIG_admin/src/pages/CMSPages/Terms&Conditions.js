import React, { useState, useEffect } from 'react'
import useApiPost from '../hooks/postData'
import toast from 'react-hot-toast'
import JoditEditor from 'jodit-react'
import { useGetPrivacyPolicyQuery } from '../../store/api/GetPrivacyPolicy&TermsConditions'
import Cookies from 'js-cookie'
import { useSelector } from 'react-redux'

const editorConfig = {
  readonly: false,
  height: 520,
  toolbarAdaptive: false,
}

function TermsConditions() {
  const [Terms, setTerms] = useState('')
  const { data, error, postData } = useApiPost()

  const token = Cookies.get("Snapta_Admin_Token")
  const { data: PolicyData, refetch: PolicyRefetch } = useGetPrivacyPolicyQuery({ token: token })
  const currentTerms = PolicyData?.terms

  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen)

  // Set terms once the data is available
  useEffect(() => {
    if (currentTerms) {
      setTerms(currentTerms) // Set Terms here
    }
  }, [currentTerms])

  const handleAddPolicy = () => {
    try {
      postData("/update_policy", { terms: Terms })
      PolicyRefetch()
      toast.success("Terms & Conditions updated Successfully!")
    } catch (error) {
      console.error(error)
    }
  }

  return (
    // <div className={`mb-10 ${isSidebarOpen ? "xl:pl-20" : "xl:pl-72"}`}>

<div className="space-y-5 ">

      <form className="space-y-6">
        <div>
          <label className="block mb-2 text-2xl font-semibold dark:text-darkText">Terms & Conditions</label>
          <div className="p-4 bg-white border rounded shadow h-[550px]">
            <JoditEditor
              value={Terms}  // Use the state directly for value
              config={editorConfig}
              onChange={(newContent) => {
                console.log("Editor content:", newContent);  // Debugging the editor change
                setTerms(newContent)
              }} // Update the state on change
            />
          </div>
        </div>
      </form>

      {/* Submit Button */}
      <button
        className='flex gap-1.5 mt-5 place-items-center px-6 py-2 rounded-lg font-poppins font-medium text-[#FFFFFF] bg-button-gradient'
        onClick={handleAddPolicy}
      >
        Submit
      </button>
    </div>
  )
}

export default TermsConditions;