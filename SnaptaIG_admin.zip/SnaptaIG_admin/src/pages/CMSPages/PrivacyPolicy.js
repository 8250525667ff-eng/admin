import React,{useState,useEffect,useRef} from 'react';
import Searchbar from '../../components/Search';
import { Link } from 'react-router-dom';
import useApiPost from '../hooks/postData';
import TermsConditions from './Terms&Conditions';
import toast from 'react-hot-toast';
import JoditEditor from 'jodit-react'
import { useSelector } from 'react-redux';
import { useGetPrivacyPolicyQuery } from '../../store/api/GetPrivacyPolicy&TermsConditions';
import Cookies from 'js-cookie'
import DeleteAccount from './DeleteAccount'
import { useNavigate } from 'react-router-dom';

  const editorConfig = {
    readonly: false,
    height: 520,
    toolbarAdaptive: false,
  };

function PrivacyPolicy() {

    const [privacyPolicy, setPrivacyPolicy] = useState('')
    const {data,error,postData} = useApiPost()

    const token = Cookies.get("Snapta_Admin_Token")
    const {data:PolicyData,refetch:PolicyRefetch} = useGetPrivacyPolicyQuery({token:token})
    const PrivacyPolicy = PolicyData?.privacy_policy
    const navigate = useNavigate()

    const handleAddPolicy = () => {
      try{
        const response = postData("/update_policy",{privacy_policy:privacyPolicy})
        PolicyRefetch()
        toast.success("Policy Updated Successfully!")
      } catch(error) {
    
      }
    }
    console.log("Privacy @@@@",PrivacyPolicy)

  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);
 

  return (
    <div className={`mb-10 ${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
      <Searchbar />

      {/* Navigation Path */}
      <div className="flex items-center justify-between px-6 my-3">
          <div className="flex items-center gap-2">
            <Link to="/dashboard"><h3 className="text-[#3A3A3A] font-poppins text-base font-semibold dark:text-darkText">Dashboard</h3></Link>
            <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
              <h3 className="text-[#858585] font-poppins text-base">CMS Pages</h3>
          </div>
      </div>

      {/* Privacy Policy T&C */}
      <div className="p-3 space-y-5 md:p-6">
      <form className="space-y-6">
        {/* Privacy Policy */}
        <div>
          <label className="block mb-2 text-2xl font-semibold dark:text-darkText">Privacy Policy</label>
          <div className="p-4 bg-white border rounded shadow h-[550px]">
            <JoditEditor
                value={PrivacyPolicy || privacyPolicy}
                config={editorConfig}
                onChange={setPrivacyPolicy}
              />
          </div>
        </div>
      </form>
       
        <button className='flex gap-1.5 place-items-center px-6 py-2 bg-button-gradient rounded-lg font-poppins font-medium text-[#FFFFFF]'
        onClick={handleAddPolicy}>
          Submit
        </button>

        {/* Terms and Conditions */}
        <TermsConditions />

        {/* Delete Account */}
        <DeleteAccount />
    </div>

      
    </div>
  );
}

export default PrivacyPolicy;
