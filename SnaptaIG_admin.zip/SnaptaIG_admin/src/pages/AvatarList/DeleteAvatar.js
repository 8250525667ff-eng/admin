import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import '../../components/DialogBoxCustom.css' 
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import { HiOutlineTrash } from "react-icons/hi2";
import { useGetAllAvtarQuery } from "../../store/api/GetAllAvtarList";
import Cookies from 'js-cookie'
import Loader from '../../assets/Loader.gif'

function DeleteAvatar({ open, handleClose ,handleRefetch, avatarId }) {

    const {data,error,postData,loading} = useApiPost()
    const token = Cookies.get("Snapta_Admin_Token")
    const {data:AvtarData} = useGetAllAvtarQuery({token:token})
    const handleDeleteAvatar = () => {
        try{
            const response = postData("/delete_avtar",{avtar_id:avatarId})
            handleRefetch()
            handleClose()
            toast.success("Avatar Deleted Successfully!")
            
        } catch(error) {
            
        }
    }
    console.log("Avtar @3344",avatarId)
    
    return (
        <Dialog open={open} onClose={handleClose}  fullWidth className="custom-dialog">
            <DialogContent className="flex flex-col items-center text-center dark:bg-primary">
                {/* Delete Icon */}
                <div className="flex justify-center p-2 rounded-full 2xl:p-4 bg-opacityGradient">
                    {/* <img src={Delete} alt="delete" className="w-9 h-9" /> */}
                    <HiOutlineTrash  className="text-header" style={{ fontSize: "35px"}}/>
                </div>

                {/* Confirmation Text */}
                <h2 className="text-xl font-poppins text-[#000000] mt-4 dark:text-darkText">Are you sure you want to delete?</h2>
                <p className="text-[#606060] font-poppins text-base mt-2 w-[320px]">
                    This avatar will be deleted permanently. You cannot undo this action.
                </p>
            </DialogContent>
            
            <DialogContent className="flex justify-center gap-4 pb-4 dark:bg-primary">
                <div className="flex justify-center gap-3">
                    <button className="w-[220px] py-2 rounded-lg dark:text-darkText border border-header text-[#3A3333] font-medium" onClick={handleClose}>
                        Cancel
                    </button>
                    <button onClick={handleDeleteAvatar} className="w-[220px] py-2 font-medium text-white rounded-lg bg-button-gradient">
                        
                        Delete
                        
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default DeleteAvatar;
