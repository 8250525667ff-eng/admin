import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import '../ReelList/style.css'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import { HiOutlineTrash } from "react-icons/hi2";
import Cookies from 'js-cookie'
import { useGetAllSettingsQuery } from "../../store/api/GetAllGeneralSettings";
import { useNavigate } from "react-router-dom";
import {useAuth} from '../../context/AuthContext'
import { ClipLoader } from "react-spinners";

function DeletePost({ open, handleClose }) {

    const {data,error,postData} = useApiPost();
    const token = Cookies.get("Snapta_Admin_Token")
    const { data: SettingData, refetch } = useGetAllSettingsQuery({ token });
    const navigate = useNavigate()
  const { verifyToken } = useAuth();
  const [isLoading,setIsLoading] = useState(false)

    
  const handleDeactive = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/expire-token`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ token }), // Only token as required
      });

      const result = await response.json();

      if (response.ok) {
        console.log("Deactivated successfully:", result);
        refetch(); // Refresh settings if needed
      } else {
        console.error("Failed to deactivate:", result?.message);
      }
      Cookies.remove("PurchaseToken")
      Cookies.remove("token")
      await verifyToken();
      navigate("/signin");
    } catch (error) {
      console.error("Error during deactivation:", error);
    } finally{
      setIsLoading(false)
    }
  };


    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="custom-dialog" >
            <DialogContent className="flex flex-col items-center text-center dark:bg-primary">
                {/* Delete Icon */}
                <div className="flex justify-center p-2 rounded-full 2xl:p-4 bg-opacityGradient dark:bg-purple-300">
                    {/* <img src={Delete} alt="delete" className="w-9 h-9" /> */}
                    <HiOutlineTrash  className="text-header" style={{ fontSize: "35px"}}/>
                </div>

                {/* Confirmation Text */}
                <h2 className="text-xl font-poppins text-[#000000] dark:text-darkText mt-4">Are you sure you want to deactive Purchase Code?</h2>
            </DialogContent>
            
            <DialogContent className="flex justify-center gap-4 pb-4 dark:bg-primary">
                <div className="flex justify-center gap-3">
                    <button className="w-[200px] py-2 rounded-lg border border-header text-[#3A3333] dark:text-darkText font-medium" onClick={handleClose}>
                        Cancel
                    </button>
                    <button onClick={handleDeactive} className="w-[200px] py-2 font-medium text-white rounded-lg  bg-button-gradient">
                        {isLoading ? (<><ClipLoader
                  loading={isLoading}
                  size={20}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                  color="#FFFFFF"
                /></>) : (<>Deactive</>)}
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default DeletePost;
