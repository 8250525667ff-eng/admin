import React, { useState,useEffect } from "react";
import Logo from '../../assets/logo.png'
import Cookies from 'js-cookie'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import {useGetAllSettingsQuery} from '../../store/api/GetAllGeneralSettings'
import axios from 'axios'
import ColorPicker from 'react-pick-color';

function GeneralSetting() 
{
    const token = Cookies.get("Snapta_Admin_Token")
    const {data:SettingData,refetch} = useGetAllSettingsQuery({token:token})
    const {data,error,postData} = useApiPost()
    const SettingsData = SettingData?.setting_list
    console.log("Settings !!!",SettingsData)
    const [isEdited,setIsEdited] = useState(false)
    const [color,setColor] = useState('')
    const [primaryColor,setPrimaryColor] = useState(false)
    const [secondaryColor,setSecondaryColor] = useState(false)

    console.log("Color 123@@",color)

    // To see the change of fields 
    const handleChange = (field, value) => {
      setFormData(prev => ({ ...prev, [field]: value }));
      setIsEdited(true);
    };

    const [imageFiles, setImageFiles] = useState({
      dark_logo: null,
      light_logo: null,
      fav_icon: null,
      banner_image: null,
    });
    
    // handle Image Select from system 
    const handleImageSelect = (e, type) => {
      const file = e.target.files[0];
      if (!file) return;
    
      const imageUrl = URL.createObjectURL(file);
    
      setFormData((prev) => ({
        ...prev,
        [type]: imageUrl, // for preview only
      }));
    
      setFileNames((prev) => ({
        ...prev,
        [type]: file.name,
      }));
    
      setImageFiles((prev) => ({
        ...prev,
        [type]: file,
      }));

      setIsEdited(true)
    };
    
    
    const [formData,setFormData] = useState({
        app_name: "",
        email:"",
        copyright_text:"",
        primary_color:"",
        secondary_color:"",
        dark_logo:"",
        light_logo:"",
        splash_image:"",
        fav_icon:"",
        banner_image:""
    })


    const handleSettingsUpdate = async () => {
      try {
        const formDataToUpload = new FormData();
    
        // Append text fields
        formDataToUpload.append("app_name", formData.app_name);
        formDataToUpload.append("email", formData.email);
        formDataToUpload.append("copyright_text", formData.copyright_text);
        formDataToUpload.append("primary_color", formData.primary_color);
        formDataToUpload.append("secondary_color",formData.secondary_color);
    
        // Append image files if selected
        Object.keys(imageFiles).forEach((key) => {
          if (imageFiles[key]) {
            formDataToUpload.append(key, imageFiles[key]);
          }
        });
    
        const token = Cookies.get("Snapta_Admin_Token");
    
        const response = await axios.post("/api/update_settings", formDataToUpload, {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        });
    
        toast.success(response?.data?.message || "Settings updated!");
        refetch(); // Refresh settings
        setIsEdited(false)
      } catch (err) {
        toast.error("Something went wrong");
        console.error(err);
      }
    };


    const handlePrimaryColor = (color) => {
      setFormData({ ...formData, primary_color: color.hex });
      setPrimaryColor(false); // <-- CLOSE the color picker after selecting color
    };

    const handleSecondaryColor = (color) => {
      setFormData({ ...formData, secondary_color: color.hex });
      setSecondaryColor(false); // <-- CLOSE the color picker after selecting color
    };
    
    // Inside your component:
    const [fileNames, setFileNames] = useState({
        dark_logo: "No File Chosen",
        light_logo: "No File Chosen",
        splash_image: "No File Chosen",
      });      
      
      useEffect(() => {
        if (SettingData && SettingData.setting_list) {
          const settings = SettingData.setting_list;
      
          setFormData({
            app_name: settings.app_name || "",
            email: settings.email || "",
            copyright_text: settings.copyright_text || "",
            primary_color: settings.primary_color || "",
            secondary_color: settings.secondary_color || "",
            dark_logo: settings.dark_logo || "",
            splash_image: settings.splash_image || "",
            light_logo: settings.light_logo || "",
            fav_icon: settings.fav_icon || "",
            banner_image: settings.banner_image || "",
          });
      
          setFileNames({
            dark_logo: getFileName(settings.dark_logo),
            light_logo: getFileName(settings.light_logo),
            splash_image: getFileName(settings.splash_image),
          });
        }
      }, [SettingData]);
      
      const getFileName = (url) => {
        return url ? url.split("/").pop() : "No File Chosen";
      };


console.log("Form Data @@@",formData?.primary_color)
    return(
        <>
        <h2 className="text-[#000000] font-semibold font-poppins text-xl sm:pb-4 sm:pt-0 pt-6 dark:text-darkText">General Settings</h2>
         <div className="border border-opacity-gradient dark:border-[#1F1F1F] bg-[#FFFFFF] dark:bg-primary rounded-lg p-4 mt-5 md:mt-0">
            {/* Input Fields */}
            <div className="grid gap-4 pb-5 md:grid-cols-2">
                {/* App/Website Name =============== */}
                <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">App/Website Name</label>
                    <input type="text" placeholder="Enter App/Website Name"
                     className="border dark:bg-transparent dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                    //  onChange={(e) => handleChange({ ...formData, app_name: e.target.value })}
                     onChange={(e) => handleChange("app_name", e.target.value)}

                     value={formData.app_name}/>
                </div>
                
                {/* Contact Email ========= */}
                <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">Contact Email</label>
                    <input type="text" placeholder="Enter Email"
                     className="border dark:bg-transparent dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                     value={formData.email}
                    //  onChange={(e) => setFormData({...formData, email: e.target.value}) }
                     onChange={(e) => handleChange("email", e.target.value)}
                     />
                </div>
            </div>

            <div className="grid gap-4 pb-5 md:grid-cols-2">
                {/* Dark Logo =============== */}
                <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">Dark Logo</label>
                    <div className="relative">
              <div
                style={{ background: "linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)" }}
                onClick={() => document.getElementById("dark_logo_input").click()}
                className="absolute left-2 top-3 bottom-3 h-[32px] text-[#000000] dark:text-darkText font-poppins text-xs flex items-center justify-center px-3 cursor-pointer border-r border-header py-3 "
              >
                Choose File
              </div>

              <input
                id="dark_logo_input"
                type="file"
                className="hidden dark:text-darkText"
                onChange={(e) => handleImageSelect(e, "dark_logo")}
              />
              <input
                type="text"
                placeholder={fileNames.dark_logo}
                className="border dark:bg-transparent placeholder:text-darkText dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 pl-[110px] my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                style={{ height: '48px' }}
              />
              {formData.dark_logo && <img src={formData.dark_logo} className="w-20" />}
            </div>
                </div>
                
                {/* Light Logo ========= */}
                <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">Light Logo</label>
                    <div className="relative">
              <div
                style={{ background: "linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)" }}
                onClick={() => document.getElementById("light_logo_input").click()}
                className="absolute left-2 top-3 bottom-3 dark:text-darkText h-[32px] text-[#000000] font-poppins text-xs flex items-center justify-center px-3 cursor-pointer border-r border-header py-3 "
              >
                Choose File
              </div>

              <input
                id="light_logo_input"
                type="file"
                className="hidden"
                onChange={(e) => handleImageSelect(e, "light_logo")}
              />
              <input
                type="text"
                placeholder={fileNames.light_logo}
                className="border dark:bg-transparent placeholder:text-darkText dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 pl-[110px] my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                style={{ height: '48px' }}
              />
              {formData.light_logo && <img src={formData.light_logo} className="w-20" />}
            </div>
                </div>
            </div>

            {/*  */}
            <div className="grid gap-4 md:grid-cols-2">
              {/* Splash Image */}
              <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">Splash Image</label>
                    <div className="relative">
              <div
                style={{ background: "linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)" }}
                onClick={() => document.getElementById("splash_image_input").click()}
                className="absolute left-2 top-3 bottom-3 h-[32px] text-[#000000] dark:text-darkText font-poppins text-xs flex items-center justify-center px-3 cursor-pointer border-r border-header py-3 "
              >
                Choose File
              </div>

              <input
                id="splash_image_input"
                type="file"
                className="hidden dark:text-darkText"
                onChange={(e) => handleImageSelect(e, "splash_image")}
              />
              <input
                type="text"
                placeholder={fileNames.splash_image}
                className="border dark:bg-transparent placeholder:text-darkText dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 pl-[110px] my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                style={{ height: '48px' }}
              />
              {formData.splash_image && <img src={formData.splash_image} className="w-20" />}
            </div>
                </div>
                {/* Copyright Text */}
                <div>
                    <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">Copyright Text</label>
                    <input type="text" placeholder="Enter Language Name"
                    className="border border-opacity-gradient dark:bg-transparent dark:text-darkText dark:border-borderColor rounded-lg w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                    value={formData.copyright_text}
                    // onChange={(e) => setFormData({...formData,copyright_text:e.target.value})}
                    onChange={(e) => handleChange("copyright_text", e.target.value)}
                    />
                </div>
            </div>
         </div>

         {/* App Color */}
     
          <div className="border border-opacity-gradient dark:border-[#1F1F1F] bg-[#FFFFFF] dark:bg-primary rounded-lg px-4 sm:py-8 py-4 my-8">
      <h2 className="text-base font-semibold font-poppins text-header">App Settings</h2>



       <div className="gap-4 pb-4 sm:flex">
         {/* Primary Color */}
         <div className="sm:w-1/2">
         <p className="text-[#000000] text-sm font-semibold py-3 font-poppins dark:text-darkText">
        Primary Color
      </p>
      <div 
        className="relative  p-2 border border-opacity-gradient dark:border-[#1F1F1F] rounded-2xl cursor-pointer"
        onClick={() => setPrimaryColor(true)}
      >
        <div
          className="w-full py-2 rounded-2xl"
          style={{ backgroundColor: formData.primary_color }}
        ></div>

        {primaryColor && (
          <div className="absolute z-50 mt-2">
            <ColorPicker color={formData.primary_color} onChange={handlePrimaryColor} />
          </div>
        )}
      </div>
      </div>

      {/* Secondary Color */}
      
      <div className="sm:w-1/2">
      <p className="text-[#000000] text-sm font-semibold py-3 font-poppins dark:text-darkText">
        Secondary Color
      </p>
      <div 
        className="relative p-2 border border-opacity-gradient dark:border-[#1F1F1F] rounded-2xl cursor-pointer"
        onClick={() => setSecondaryColor(true)}
      >
        <div
          className="w-full py-2 rounded-2xl"
          style={{ backgroundColor: formData.secondary_color }}
        ></div>

        {secondaryColor && (
          <div className="absolute z-50 mt-2">
            <ColorPicker color={formData.secondary_color} onChange={handleSecondaryColor} />
          </div>
        )}
      </div>
      </div>


       </div>
      
    </div>

         


         {/* Submit Button */}
         <div className="flex justify-center py-6 place-items-center">
            <button className={`px-24 py-3 font-medium bg-opacity-[80%] text-white rounded-xl ${isEdited ? "bg-button-gradient" : "bg-header bg-opacity-[45%]"}`} 
            onClick={handleSettingsUpdate}>
                Submit
            </button>
         </div>
        </>
    )
}

export default GeneralSetting


