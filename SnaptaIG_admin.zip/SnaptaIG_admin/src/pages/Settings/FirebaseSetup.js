import React, { useState, useEffect } from 'react';
import { FiInfo } from "react-icons/fi";
import useApiPost from '../hooks/postData';
import axios from 'axios';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';
import { useGetFileQuery } from '../../store/api/FirebaseFileCredentials';

function FirebaseSetup() {
  const [jsonFileName, setJsonFileName] = useState("");
  const token = Cookies.get("Snapta_Admin_Token");

  const { data: fileData } = useGetFileQuery({ token });
  const { data, error, postData } = useApiPost(); // ✅ call the hook

  const [formData, setFormData] = useState({
    firebase_credentials: "",
  });

  // Handle file upload
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file && file.type === "application/json") {
      setJsonFileName(file.name);

      const uploadForm = new FormData();
      uploadForm.append("firebase_credentials", file);

      try {
        const response = await axios.post(
          "/api/upload_firebasecredentials",
          uploadForm,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        toast.success("File uploaded successfully");

        const uploadedFileName = response.data?.file_name || file.name;
        setFormData({ firebase_credentials: uploadedFileName });
      } catch (error) {
        console.error("Upload failed:", error);
        toast.error("Failed to upload JSON file.");
      }
    } else {
      setJsonFileName("Invalid file. Please upload a JSON file.");
    }
  };

  // Set form data from API response if available
  useEffect(() => {
    const fetchedFileName = fileData?.file_name;
    if (fetchedFileName) {
      setFormData({ firebase_credentials: fetchedFileName });
    }
  }, [fileData]);

  return (
    <>
      <h2 className="text-[#000000] font-semibold font-poppins text-xl pt-6 sm:pt-0 pb-4 dark:text-darkText">Firebase Setup</h2>
      <div className="sm:mt-5 border rounded-lg border-opacity-gradient dark:border-[#1F1F1F] md:mt-0 p-4">
        <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
          Upload JSON File
        </label>

        <div className="relative">
          <div
            style={{
              background:
                "linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)",
            }}
            onClick={() => document.getElementById("json_input").click()}
            className="absolute left-2 top-3 bottom-3 h-[32px] text-[#000000] dark:text-darkText font-poppins text-xs flex items-center justify-center px-3 cursor-pointer border-r border-header py-3"
          >
            Upload File
          </div>

          {/* Hidden input for JSON upload */}
          <input
            id="json_input"
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleFileChange}
          />

          {/* Display file name in placeholder */}
          <input
            type="text"
            value={formData.firebase_credentials}
            
            placeholder="Choose a file"
            className="border dark:bg-transparent placeholder:text-darkText dark:text-darkText dark:border-borderColor border-opacity-gradient rounded-lg w-full py-3 pl-[110px] my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
            style={{ height: "48px" }}
          />
        </div>

        {/* Info Box */}
        <div className="flex gap-4 my-6 rounded-lg bg-opacityGradient">
          <div className='bg-[#452B7A] bg-opacity-80 py-5 px-3'>
            <FiInfo className="w-8 h-8 text-white rounded-lg" />
          </div>
          <h2 className="py-4 text-base font-semibold font-poppins dark:text-darkText">
            Info -{" "} 
            <span className='block text-xs font-medium sm:hidden font-poppins'>
            Open Firebase Console → Open Project Settings → Click the ⚙️ gear icon next to “Project Overview” → Select “Project settings” → Go to 
            “Service Accounts” Tab → Generate new private key → Confirm and download the .json file
            </span>
            <span className="hidden text-sm font-medium font-poppins dark:text-darkText sm:block">
              Open Firebase Console → Open Project Settings → Click the ⚙️ gear icon next to “Project Overview” → Select “Project settings” → Go to 
              <br />
              <span className="hidden pl-12 dark:text-darkText sm:block">
              “Service Accounts” Tab → Generate new private key → Confirm and download the .json file
              </span>
            </span>
          </h2>
        </div>
      </div>
    </>
  );
}

export default FirebaseSetup;
