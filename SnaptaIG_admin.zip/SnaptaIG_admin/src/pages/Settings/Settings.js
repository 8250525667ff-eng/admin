import React, { useState,useEffect } from "react";
import Searchbar from "../../components/Search";
import Search from '../../assets/search.png'
import { Link } from "react-router-dom";
import General from '../../assets/setting.png'
import sms from '../../assets/smsSetting.png'
import mail from '../../assets/messageSetting.png'
import purchase from '../../assets/key.png'
import General1 from '../../assets/setting1.png'
import sms1 from '../../assets/smsSetting1.png'
import mail1 from '../../assets/messageSetting1.png'
import purchase1 from '../../assets/key1.png'
import GeneralSetting from "./GeneralSetting";
import SMSConfiguration from './SMSConfiguration'
import MailSetup from "./MailSetup";
import FirebaseSetup from "./FirebaseSetup";
import PurchaseCode from "./PurchaseCodeField";
import { useSelector } from "react-redux";
import Bucket from './AWSMediaStorage'
import { PiFileArrowUpLight } from "react-icons/pi";
import Cookies from 'js-cookie'
import { useNavigate } from "react-router-dom";
import { IoCloudyOutline } from "react-icons/io5";
import LoginConfiguration from "./LoginConfiguration";
import login from '../../assets/login.png'
import login1 from '../../assets/login1.png'
import payment from '../../assets/payment.png'
import payment1 from '../../assets/payment1.png'
import PaymentMethod from "./PaymentMethod";

function Settings() 
{
    const [option,setOption] = useState("General");
  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);
  

    return(
        <>
         <div className={`${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
            <Searchbar />

            <div className="flex justify-between border-[#F2F2F2] py-3 xl:px-6 2xl:px-6 px-4">
                <h2 className="text-[#000000] font-poppins text-xl font-semibold pt-3 dark:text-darkText">Settings</h2>
                <div className="relative">
                    <div className="absolute flex items-center p-2 transform -translate-y-1/2 left-2 top-1/2">
                      <img src={Search} alt="Search" className="w-5 h-5" />
                    </div>

                    {/* <input type="text" className="border border-gray-500 bg-[#00000005] border-opacity-10 rounded-lg w-[250px] py-2 pl-12 placeholder:text-sm placeholder:text-[#0000004F] focus:outline-none focus:ring-1 focus:ring-gray-600"
                     placeholder="Search Title"/> */}
                </div>
            </div>
            
            {/* Navigation Path */}
            <div className="flex items-center justify-between px-4 xl:px-6">
                <div className="flex items-center gap-2">
                    <Link to="/dashboard"><h3 className="text-[#3A3A3A] font-poppins text-base font-semibold dark:text-darkText">Dashboard</h3></Link>
                    <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
                    <h3 className="text-[#858585] font-poppins text-base">Settings</h3>
                </div>
            </div>

            {/* Main board */}
            <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] h-fit mx-6 my-6 rounded-lg px-6 py-6">
                {/* Outer div */}
                <div className="md:flex gap-14">

                    {/* Option Buttons */}
                    <div className="flex flex-col gap-4">
                        {/* General Setting ================================== */}
                        <button className={`flex px-4 gap-2 lg:w-[320px] md:w-[220px] py-3.5 2xl:py- rounded-xl 
                        ${option === "General" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                        onClick={() => setOption("General")}>
                            <img src={option === "General" ? General : General1} className="block w-5 h-5 dark:hidden"/>
                            <img src={General} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "General" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>General Settings</p>
                        </button>

                        {/* SMS Configuration Button =============================*/}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "SMS" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                       
                        onClick={() => setOption("SMS")}>
                            {/* <img src={option === "SMS" ? mail1 : mail} className="w-5 h-5"/> */}
                            <img src={option === "SMS" ? mail1 : mail} className="block w-5 h-5 dark:hidden"/>
                            <img src={mail1} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "SMS" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>SMS Configuration</p>
                        </button>

                        {/* Mail Setup ==================================*/}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Mail" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                        onClick={() => setOption("Mail")}>
                            {/* <img src={option === "Mail" ? sms1 : sms} className="w-5 h-5"/> */}
                            <img src={option === "Mail" ? sms1 : sms} className="block w-5 h-5 dark:hidden"/>
                            <img src={sms1} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "Mail" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Mail Setup</p>
                        </button>

                        {/* AWS BUcket =================================== */}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "AWS" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                        onClick={() => setOption("AWS")}>
                            <IoCloudyOutline className={`dark:text-[#FFFFFF] w-5 h-5 ${option === "AWS" ? "text-[#FFFFFF]" : "text-[#000000]"}`} />
                            <p className={`font-poppins text-sm font-normal ${option === "AWS" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>AWS Media Storage</p>
                        </button>

                        {/* Firebase Setup ============================== */}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Firebase" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}

                        onClick={() => setOption("Firebase")}>
                            {/* <img src={option === "Purchase" ? purchase1 : purchase} className="w-5 h-5"/> */}
                            {/* <img src={option === "Firebase" ? purchase1 : purchase} className="block w-5 h-5 dark:hidden"/> */}
                            <PiFileArrowUpLight className={`dark:text-[#FFFFFF] w-5 h-5 ${option === "Firebase" ? "text-[#FFFFFF]" : "text-[#000000]"}`}/>
                            {/* <img src={purchase1} className="hidden w-5 h-5 dark:block"/> */}
                            <p className={`font-poppins text-sm font-normal ${option === "Firebase" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Firebase Setup</p>
                        </button>

                        {/* Payment Gateway Button ============================== */}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Payment" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                       
                        onClick={() => setOption("Payment")}>
                            {/* <img src={option === "SMS" ? mail1 : mail} className="w-5 h-5"/> */}
                            <img src={option === "Payment" ? payment1 : payment} className="block w-5 h-5 dark:hidden"/>
                            <img src={payment1} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "Payment" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Payment Method</p>
                        </button>

                        {/* Login Configuration Button ============================== */}
                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Login" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}
                       
                        onClick={() => setOption("Login")}>
                            {/* <img src={option === "SMS" ? mail1 : mail} className="w-5 h-5"/> */}
                            <img src={option === "Login" ? login : login1} className="block w-5 h-5 dark:hidden"/>
                            <img src={login} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "Login" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Login Configuration</p>
                        </button>

                        {/* Purchase Code Field =========================== */}

                        <button className={`font-poppins text-sm flex text-left font-normal px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Purchase" ? "bg-button-gradient" : "border border-opacity-gradient dark:border-[#1F1F1F]"}`}

                        onClick={() => setOption("Purchase")}>
                            {/* <img src={option === "Purchase" ? purchase1 : purchase} className="w-5 h-5"/> */}
                            <img src={option === "Purchase" ? purchase1 : purchase} className="block w-5 h-5 dark:hidden"/>
                            <img src={purchase1} className="hidden w-5 h-5 dark:block"/>
                            <p className={`font-poppins text-sm font-normal ${option === "Purchase" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Purchase Code</p>
                        </button>

                        {/* <button className={`flex px-4 gap-2 lg:w-[320px] py-3.5 rounded-xl
                        ${option === "Purchase" ? "bg-button-gradient" : "border border-opacity-gradient bg-[#FFFFFF]"}`}
                        
                        onClick={() => setOption("Purchase")}>
                            <img src={option === "Purchase" ? purchase1 : purchase} className="w-5 h-5"/>
                            <p className={`font-poppins text-sm font-normal ${option === "Purchase" ? "text-[#FFFFFF]" : "text-[#000000] dark:text-darkText"}`}>Purchase Code Field</p>
                        </button> */}
                    </div>

                    {/* Pages  */}
                    <div className="w-full">
                        
                    {option === "General" && 
                    <GeneralSetting />}

                    {option === "SMS" && 
                    <SMSConfiguration />}

                    {option === "Login" && 
                    <LoginConfiguration />}

                    {option === "Payment" && 
                    <PaymentMethod />}

                    {option === "Mail" && 
                    <MailSetup />}

                    {option === "AWS" && 
                    <Bucket />}

                    {option === "Firebase" && 
                    <FirebaseSetup />}

                    {option === "Purchase" && 
                    <PurchaseCode />}

                    </div>
                    
                </div>
            </div>
         </div>
        </>
    )
}

export default Settings;


