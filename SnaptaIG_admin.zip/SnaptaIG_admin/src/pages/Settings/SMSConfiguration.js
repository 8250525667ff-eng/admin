import React, { useState, useEffect } from "react";
import { useGetAllKeyQuery } from "../../store/api/GetAllTwilioKey";
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import Cookies from "js-cookie";
import { ClipLoader } from "react-spinners";

function SMSConfiguration() {
  const [option, setOption] = useState("Twilio");
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: KeyData, refetch } = useGetAllKeyQuery({ token: token });
  const { data, error, postData,loading } = useApiPost();
  const [isEdited, setIsEdited] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  console.log("Settings !!!", KeyData);

  const [formData, setFormData] = useState({
    twilio_sid: "",
    twilio_auth_token: "",
    twilio_phone_number: "",
    msg91_auth_key: "",
    msg91_private_key: "",
  });

  // To see the change of fields
  // const handleChange = (field, value) => {
  //   setFormData((prev) => ({ ...prev, [field]: value }));
  //   setIsEdited(true);
  // };
  const [editedFields, setEditedFields] = useState({
      twilio_sid: false,
      twilio_auth_token: false,
      twilio_phone_number: false,
      msg91_auth_key: false,
      msg91_private_key:false,
    });

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));

    if (!editedFields[field]) {
      setEditedFields((prev) => ({ ...prev, [field]: true }));
    }

    setIsEdited(true);
  };

  const handleKeyUpdate = async () => {
    try {
      const response = await postData("/update_all_key", formData);

      toast.success(response.message || "Keys updated!");
      refetch(); // Refetch new settings if needed
      setIsEdited(false);
      setEditedFields({
      twilio_sid: false,
      twilio_auth_token: false,
      twilio_phone_number: false,
      msg91_auth_key: false,
      msg91_private_key:false,
    });
    } catch (err) {
      toast.error("Something went wrong");
      console.error(err);
    }
  };

  // Inside your component:
  useEffect(() => {
    if (KeyData) {
      setFormData({
        twilio_sid: KeyData.twilio_sid || "",
        twilio_auth_token: KeyData.twilio_auth_token || "",
        twilio_phone_number: KeyData.twilio_phone_number || "",
        msg91_auth_key: KeyData.msg91_auth_key || "",
        msg91_private_key: KeyData.msg91_private_key || "",
      });
    }
  }, [KeyData]);

  return (
    <>
      <h2 className="text-[#000000] font-semibold font-poppins text-xl pb-4 pt-6 sm:pt-0 dark:text-darkText">
        SMS Configuration
      </h2>

      <div className="sm:mt-5 border rounded-lg border-opacity-gradient dark:border-[#1F1F1F] md:mt-0">
        <div className="grid grid-cols-2">
          {/* Twilio */}
          <button
            className={`font-poppins font-semibold w-full py-3 border-b dark:border-[#1F1F1F] rounded-tl-lg text-sm ${
              option === "Twilio"
                ? "text-[#FFFFFF] bg-button-gradient"
                : " text-[#5B5B5B]"
            }`}
            onClick={() => setOption("Twilio")}
          >
            Twilio
          </button>

          {/* MSG 91 */}
          <button
            className={`font-poppins font-semibold border-b dark:border-[#1F1F1F] w-full py-3 rounded-tr-lg text-sm ${
              option === "MSG"
                ? "text-[#FFFFFF] bg-button-gradient"
                : " text-[#5B5B5B]"
            }`}
            onClick={() => setOption("MSG")}
          >
            MSG 91
          </button>
        </div>

        {/* Twilio */}
        {option === "Twilio" && (
          <div className="p-4">
            <div className="grid gap-4 py-4 md:grid-cols-2">
              {/* Twilio Account SID */}
              <div>
                <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
                  Twilio Account SID
                </label>

                <input
              type={editedFields.twilio_sid ? "text" : "password"}
              placeholder="Enter Twilio SID"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:placeholder:text-darkText dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              onChange={(e) =>
                handleChange("twilio_sid", e.target.value)
              }
              value={formData.twilio_sid}
            />


              </div>

              {/* Twilio Auth Token */}
              <div>
                <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
                  Twilio Auth Token
                </label>
                <input
                  type={editedFields.twilio_auth_token ? "text" : "password"}
                  placeholder="Enter Mail Password"
                  className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:placeholder:text-darkText dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                  value={formData.twilio_auth_token}
                  onChange={(e) =>
                    handleChange("twilio_auth_token", e.target.value)
                  }
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2">
              {/* Twilio Phone Number */}
              <div>
                <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
                  Twilio Phone Number
                </label>

                <input
                  type={editedFields.twilio_phone_number ? "text" : "password"}
                  placeholder="Enter Twilio Phone Number"
                  className="border border-opacity-gradient rounded-md  w-full py-3 my-1 dark:placeholder:text-darkText px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                  value={formData.twilio_phone_number}
                  onChange={(e) =>
                    handleChange("twilio_phone_number", e.target.value)
                  }
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-20 pb-4 place-items-center">
              <button
                className={`px-24 py-3 text-lg font-medium text-white rounded-xl ${
                  isEdited ? "bg-button-gradient" : "bg-header bg-opacity-[45%]"
                }`}
                onClick={handleKeyUpdate}
              >
                {loading ? (<>
                <ClipLoader
                                  loading={loading}
                                  size={20}
                                  aria-label="Loading Spinner"
                                  data-testid="loader"
                                  color="#FFFFFF"
                                />
                </>) : (<>Submit</>)}
              </button>
            </div>
          </div>
        )}

        {option === "MSG" && (
          <div className="p-4">
            <div className="grid gap-4 py-4 md:grid-cols-2">
              {/* MSG91 Auth Key */}
              <div>
                <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
                  MSG91 Auth Key
                </label>

                <input
                  type={editedFields.msg91_auth_key ? "text" : "password"}
                  placeholder="Enter Mail Password"
                  className="border border-opacity-gradient rounded-md w-full  py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                  value={formData.msg91_auth_key}
                  onFocus={() => setShowPassword(true)}
                  onChange={(e) =>
                    handleChange("msg91_auth_key", e.target.value)
                  }
                />
              </div>

              {/* MSG91 Private Key */}
              <div>
                <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
                  MSG91 Private Key
                </label>

                <input
                  type={editedFields.msg91_private_key ? "text" : "password"}
                  placeholder="Enter Mail Password"
                  className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                  value={formData.msg91_private_key}
                  onFocus={() => setShowPassword(true)}
                  onChange={(e) =>
                    handleChange("msg91_private_key", e.target.value)
                  }
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-16 pb-4 place-items-center">
              <button
                className={`w-[240px] py-3 text-lg font-medium text-white rounded-xl ${
                  isEdited ? "bg-button-gradient" : "bg-header bg-opacity-[45%]"
                }`}
                onClick={handleKeyUpdate}
              >
                {loading ? (<>
                <ClipLoader
                                  loading={loading}
                                  size={20}
                                  aria-label="Loading Spinner"
                                  data-testid="loader"
                                  color="#FFFFFF"
                                />
                </>) : (<>Submit</>)}
                
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default SMSConfiguration;
