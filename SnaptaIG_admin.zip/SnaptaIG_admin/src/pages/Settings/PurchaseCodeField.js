import React, { useState } from "react";
import { useGetAllSettingsQuery } from "../../store/api/GetAllGeneralSettings";
import Cookies from "js-cookie";
import DeactivePopup from './DeactivePopup'

function PurchaseCode() {
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: SettingData, refetch } = useGetAllSettingsQuery({ token });
  const purchaseCode = SettingData?.setting_list?.purchase_code || "";
  const [open,setOpen] = useState(false)

  const handleOpen = () => {
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  // Mask purchase code (first 4 and last 4)
  const maskedCode =
    purchaseCode.length >= 8
      ? `${purchaseCode.slice(0, 4)}****************************${purchaseCode.slice(-4)}`
      : purchaseCode;

  return (
    <>
    <div className="border border-[#543691] border-opacity-15 rounded-lg px-8 py-6 mt-5 md:mt-0">
      <p className="text-[#000000] font-semibold text-base pb-2 dark:text-darkText">
        Purchase Code
      </p>
      <input
        type="text"
        value={maskedCode}
        
        className="border border-[#452B7A] border-opacity-10 font-poppins text-[#000000] dark:bg-transparent dark:text-darkText dark:border-borderColor rounded-md w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-[#452B7A]"
      />

      <div className="flex justify-center pt-14 place-items-center">
        <button
          className="px-24 py-3 font-medium text-white rounded-xl bg-[#FF3838]"
          onClick={handleOpen}
        >
          Deactive
        </button>
      </div>
    </div>

    <DeactivePopup open={open} handleClose={handleClose} />

    </>
  );
}

export default PurchaseCode;
