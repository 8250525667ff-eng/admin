import React, { useState, useEffect } from "react";
import useApiPost from "../hooks/postData";
import Cookies from "js-cookie";
import toast from "react-hot-toast";
import { useGetAWSMediaQuery } from "../../store/api/AWSMediaStorageData";
import { ClipLoader } from "react-spinners";
import axios from "axios";

function AWSMediaStorage() {
  const token = Cookies.get("Snapta_Admin_Token");
  // const { data: AWSMediaData, refetch } = useGetAWSMediaQuery({ token: token });
  const { data, error, postData, loading } = useApiPost();
  const [isEdited, setIsEdited] = useState(false);
  const [isLoading,setIsLoading] = useState(false)
  // const AWSMediaStorageData = AWSMediaData?.updated_values;

  const [AWSData,setAWSData] = useState([]);
   const fetchAWSMediaData = async () => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/update-bucket`
      );
      setAWSData(response.data); // ✅ This sets only the array part
    } catch (err) {
      console.error("Failed to fetch admin login details", err);
    }
  };
  useEffect(() => {
    fetchAWSMediaData();
  }, []);
  console.log("AWS Data @#1",AWSData.updated_values)

  const AWSMediaStorageData = AWSData.updated_values

  const [showPassword, setShowPassword] = useState(false);

  const [editedFields, setEditedFields] = useState({
    aws_access_key_id: false,
    aws_secret_access_key: false,
    aws_bucket: false,
    aws_url: false,
  });

  const [formData, setFormData] = useState({
    aws_access_key_id: "",
    aws_secret_access_key: "",
    aws_bucket: "",
    aws_url: "",
  });

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));

    if (!editedFields[field]) {
      setEditedFields((prev) => ({ ...prev, [field]: true }));
    }

    setIsEdited(true);
  };

  const handleAWSMediaUpdate = async () => {
    setIsLoading(true)
  try {
    const response = await axios.post(`${process.env.REACT_APP_API_URL}/update-bucket`, formData);
    toast.success("Bucket Configuration updated successfully");
    setIsEdited(false);
    setShowPassword(false);

    // 👇 Reset editedFields to hide values again after update
    setEditedFields({
      aws_access_key_id: false,
      aws_secret_access_key: false,
      aws_bucket: false,
      aws_url: false,
    });

  } catch (err) {
    toast.error("Something went wrong");
    console.error(err);
  } finally {
    setIsLoading(false)
  }
};


  // Inside your component:
 useEffect(() => {
  if (AWSMediaStorageData) {
    const stripQuotes = (value) =>
      typeof value === "string" ? value.replace(/^"(.*)"$/, "$1") : "";

    setFormData({
      aws_access_key_id: stripQuotes(AWSMediaStorageData.aws_access_key_id),
      aws_secret_access_key: stripQuotes(AWSMediaStorageData.aws_secret_access_key),
      aws_bucket: stripQuotes(AWSMediaStorageData.aws_bucket),
      aws_url: stripQuotes(AWSMediaStorageData.aws_url),
    });

    setEditedFields({
      aws_access_key_id: false,
      aws_secret_access_key: false,
      aws_bucket: false,
      aws_url: false,
    });

    setIsEdited(false); // Reset edit state after loading
  }
}, [AWSMediaStorageData]);





  console.log("Access Key Id @#12",formData.aws_access_key_id)

  return (
    <>
      <div className="flex justify-between">
        <h2 className="font-poppins text-[#000000] dark:text-darkText text-xl font-semibold pb-4 pt-6 sm:pt-0">
          AWS Media Storage
        </h2>
      </div>
      <div className="border border-[#543691] border-opacity-15 rounded-lg px-6 pt-8 sm:mt-5 md:mt-0">
        {/* Row 1 */}
        <div className="grid gap-4 md:grid-cols-2">
          {/* Mail Mailer */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Access Key
            </label>
            <input
              type={editedFields.aws_access_key_id ? "text" : "password"}
              placeholder="Enter Access Key"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:placeholder:text-darkText dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              onChange={(e) =>
                handleChange("aws_access_key_id", e.target.value)
              }
              value={formData.aws_access_key_id}
            />
          </div>

          {/* Mail Host */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Secret Access Key
            </label>
            <input
              type={editedFields.aws_secret_access_key ? "text" : "password"}
              placeholder="Enter Secret Access Key"
              className="border border-opacity-gradient rounded-md w-full dark:placeholder:text-darkText py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              onChange={(e) => handleChange("aws_secret_access_key",e.target.value)}
              value={formData.aws_secret_access_key}
            />
          </div>
        </div>

        {/* Row 2 */}
        <div className="grid gap-4 py-5 md:grid-cols-2">
          {/* Mail Port */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Bucket Name
            </label>
            <input
              type={editedFields.aws_bucket ? "text" : "password"}
              placeholder="Enter Bucket Name"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:placeholder:text-darkText dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.aws_bucket}
              onChange={(e) => handleChange("aws_bucket", e.target.value)}
            />
          </div>

          {/* Mail Encryption */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              S3 Bucket URL
            </label>
            <input
              type={editedFields.aws_url ? "text" : "password"}
              placeholder="Enter S3 Bucket URL"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:placeholder:text-darkText dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.aws_url}
              onChange={(e) => handleChange("aws_url", e.target.value)}
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-center py-6 place-items-center">
          <button
            className={`w-[240px] py-3 font-medium text-white rounded-xl ${
              isEdited ? "bg-button-gradient" : "bg-header bg-opacity-[45%]"
            }`}
            onClick={handleAWSMediaUpdate}
          >
            {isLoading ? (
              <>
                <ClipLoader
                  loading={isLoading}
                  size={20}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                  color="#FFFFFF"
                />
              </>
            ) : (
              <>Submit</>
            )}
          </button>
        </div>
      </div>
    </>
  );
}

export default AWSMediaStorage;