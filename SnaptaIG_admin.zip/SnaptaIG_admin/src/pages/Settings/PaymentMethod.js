
import React, { useState } from "react";
import RazorPay from "./RazorPay";
import Stripe from "./Stripe";
import Paypal from "./Paypal";

function PaymentMethod() {
  const [option, setOption] = useState("Razorpay");

  return (
    <>
    <h2 className="text-[#000000] font-semibold font-poppins text-xl pb-4 pt-6 sm:pt-0 dark:text-darkText">Payment Method</h2>
      <div className="sm:mt-5 border rounded-lg border-opacity-gradient dark:border-[#1F1F1F] md:mt-0">
        <div className="grid grid-cols-3 pb-6">
          {/* Razor pay */}
          <button
            className={`font-poppins font-semibold w-full py-3 border-b border-r dark:border-[#1F1F1F] rounded-tl-lg text-sm ${
              option === "Razorpay"
                ? "text-[#FFFFFF] bg-button-gradient"
                : " text-[#5B5B5B]"
            }`}
            onClick={() => setOption("Razorpay")}
          >
            Razor Pay
          </button>

          {/* Stripe */}
          <button
            className={`font-poppins font-semibold border-b dark:border-[#1F1F1F] border-r w-full py-3 text-sm ${
              option === "Stripe"
                ? "text-[#FFFFFF] bg-button-gradient"
                : " text-[#5B5B5B]"
            }`}
            onClick={() => setOption("Stripe")}
          >
            Stripe
          </button>

          {/* Paypal */}
          <button
            className={`font-poppins font-semibold border-b dark:border-[#1F1F1F] w-full py-3 rounded-tr-lg rounded-br-lg text-sm ${
              option === "Paypal"
                ? "text-[#FFFFFF] bg-button-gradient"
                : " text-[#5B5B5B]"
            }`}
            onClick={() => setOption("Paypal")}
          >
            PayPal
          </button>
        </div>

        <div className="px-6 pb-6">
          {option === "Razorpay" && <RazorPay />}

          {option === "Stripe" && <Stripe />}

          {option === "Paypal" && <Paypal />}
        </div>
      </div>
    </>
  );
}

export default PaymentMethod;
