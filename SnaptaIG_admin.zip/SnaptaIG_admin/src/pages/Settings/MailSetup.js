import React, { useState, useEffect } from "react";
import { useGetAllMailSetupQuery } from "../../store/api/GetAllMailSetup";
import useApiPost from "../hooks/postData";
import Cookies from "js-cookie";
import toast from "react-hot-toast";
import { ClipLoader } from "react-spinners";

function MailSetup() {
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: MailSetupData, refetch } = useGetAllMailSetupQuery({
    token: token,
  });
  const { data, error, postData, loading } = useApiPost();
  const [isEdited, setIsEdited] = useState(false);
  const MailsSetupData = MailSetupData?.mail_setup_list;
  console.log("Settings !!!", MailsSetupData);

  // to handle the encrypted fields
  const [editedFields, setEditedFields] = useState({
    mail_password: false,
    mail_username: false,
    mail_from: false,
  });

  const [formData, setFormData] = useState({
    mail_mailer: "",
    mail_host: "",
    mail_port: "",
    mail_encryption: "",
    mail_username: "",
    mail_password: "",
    mail_from: "",
  });

  // To see the change of fields
  const handleChange = (field, value) => {
    setFormData((prev) => {
      const newFormData = { ...prev, [field]: value };
      if (prev[field] !== value) {
        setIsEdited(true);
        if (["mail_password", "mail_username", "mail_from"].includes(field)) {
          setEditedFields((prevState) => ({ ...prevState, [field]: true }));
        }
      }
      return newFormData;
    });
  };

  //   handle username change

  const handleMailSetupUpdate = async () => {
    try {
      const response = await postData("/update_mailsetup", formData);
      toast.success(response.message || "Mail Setup updated!");
      setIsEdited(false);
      // setShowUsername(false);  // 👈 Re-mask after update
      // setShowAddress(false)
      refetch(); // Refetch new settings if needed
    } catch (err) {
      toast.error("Something went wrong");
      console.error(err);
    }
  };

  // Inside your component:
  useEffect(() => {
    if (MailsSetupData) {
      setFormData({
        mail_mailer: MailsSetupData.mail_mailer || "",
        mail_host: MailsSetupData.mail_host || "",
        mail_port: MailsSetupData.mail_port || "",
        mail_encryption: MailsSetupData.mail_encryption || "",
        mail_username: MailsSetupData.mail_username || "",
        mail_password: MailsSetupData.mail_password || "",
        mail_from: MailsSetupData.mail_from || "",
      });
    }
  }, [MailsSetupData]);

  return (
    <>
      <h2 className="text-[#000000] font-semibold font-poppins text-xl pb-4 pt-6 sm:pt-0 dark:text-darkText">
        Mail Setup
      </h2>

      <div className="border border-[#543691] border-opacity-15 rounded-lg px-6 pt-8 sm:mt-5 md:mt-0">
        {/* Row 1 */}
        <div className="grid gap-4 md:grid-cols-2">
          {/* Mail Mailer */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Mailer
            </label>
            <input
              type="text"
              placeholder="Enter Mail Mailer"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.mail_mailer}
              // onChange={(e) => setFormData({...formData,mail_mailer:e.target.value})}
              onChange={(e) => handleChange("mail_mailer", e.target.value)}
            />
          </div>

          {/* Mail Host */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Host
            </label>
            <input
              type="text"
              placeholder="Enter Mail Host"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.mail_host}
              // onChange={(e) => setFormData({...formData,mail_host:e.target.value})}
              onChange={(e) => handleChange("mail_host", e.target.value)}
            />
          </div>
        </div>

        {/* Row 2 */}
        <div className="grid gap-4 py-5 md:grid-cols-2">
          {/* Mail Port */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Port
            </label>
            <input
              type="text"
              placeholder="Enter Mail Mailer"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.mail_port}
              // onChange={(e) => setFormData({...formData,mail_port:e.target.value})}
              onChange={(e) => handleChange("mail_port", e.target.value)}
            />
          </div>

          {/* Mail Encryption */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Encryption
            </label>
            <input
              type="text"
              placeholder="Enter Mail Host"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={formData.mail_encryption}
              // onChange={(e) => setFormData({...formData,mail_encryption:e.target.value})}
              onChange={(e) => handleChange("mail_encryption", e.target.value)}
            />
          </div>
        </div>

        {/* Row 3  */}
        <div className="grid gap-4 md:grid-cols-2">
          {/* Mail Username */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Username
            </label>
            {/* <input type="text" placeholder="Enter Mail Mailer"
                    className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                    value={formData.mail_username}
                    // onChange={(e) => setFormData({...formData,mail_username:e.target.value})}
                    onChange={(e) => handleChange("mail_username", e.target.value)}
                    /> */}
            <input
              type="text"
              placeholder="Enter Mail Username"
              className="border border-opacity-gradient  rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={
                !editedFields.mail_username
                  ? (() => {
                      const [user, domain] = formData.mail_username.split("@");
                      return user
                        ? `${"*".repeat(user.length)}${
                            domain ? `@${domain}` : ""
                          }`
                        : "";
                    })()
                  : formData.mail_username
              }
              onChange={(e) => handleChange("mail_username", e.target.value)}
            />
          </div>

          {/* Mail Password */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail Password
            </label>

            <input
              type="text"
              placeholder="Enter Mail Password"
              className="border border-opacity-gradient  rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={
                !editedFields.mail_password
                  ? "*".repeat(formData.mail_password.length)
                  : formData.mail_password
              }
              onChange={(e) => handleChange("mail_password", e.target.value)}
            />
          </div>
        </div>

        {/* Row 4 */}
        <div className="grid py-5 md:grid-cols-2">
          {/* Mail From Address */}
          <div>
            <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
              Mail from Address
            </label>

            <input
              type="text"
              placeholder="Enter Mail Address"
              className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
              value={
                !editedFields.mail_from
                  ? (() => {
                      const [user, domain] = formData.mail_from.split("@");
                      return user
                        ? `${"*".repeat(user.length)}${
                            domain ? `@${domain}` : ""
                          }`
                        : "";
                    })()
                  : formData.mail_from
              }
              onChange={(e) => handleChange("mail_from", e.target.value)}
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-center py-6 place-items-center">
          <button
            className={`w-[240px] py-3 font-medium text-white rounded-xl ${
              isEdited ? "bg-button-gradient" : "bg-header bg-opacity-[45%]"
            }`}
            onClick={handleMailSetupUpdate}
          >
            {loading ? (<>
             <ClipLoader
                  loading={loading}
                  size={20}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                  color="#FFFFFF"
                />
            </>) : (<>Submit</>)}
            
          </button>
        </div>
      </div>
    </>
  );
}

export default MailSetup;
