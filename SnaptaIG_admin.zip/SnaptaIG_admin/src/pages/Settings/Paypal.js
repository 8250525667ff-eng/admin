



import React, { useState, useEffect } from 'react';
import axios from 'axios';
import useApiPost from '../hooks/postData';
import { ClipLoader } from 'react-spinners';
import toast from 'react-hot-toast'

function PayPal() {
  const [publicKey, setPublicKey] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [editedPublicKey, setEditedPublicKey] = useState(false);
  const [editedSecretKey, setEditedSecretKey] = useState(false);
  const [status, setStatus] = useState('');
  const [id, setId] = useState(null);
  const [isLoading,setIsLoading] = useState(false)

  const { data,loading,postData } = useApiPost();
  const fetchPaymentDetails = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/all_payment_gateway_key`);
        const razorPayData = response?.data?.data.find(item => item.text === "Paypal");

        if (razorPayData) {
          setPublicKey(razorPayData.public_key || '');
          setSecretKey(razorPayData.secret_key || '');
          setStatus(razorPayData.status || '0');
          setId(razorPayData.id);
        }
      } catch (err) {
        console.error('Failed to fetch Razorpay details', err);
      }
    };
  useEffect(() => {
    fetchPaymentDetails();
  }, []);

  const handleToggle = async () => {
  const newStatus = status === "1" ? "0" : "1";

  try {
    const formData = new FormData();
    formData.append("id", id);
    formData.append("status", newStatus);

    await postData("/update_payment_gateway", formData);
    setStatus(newStatus);
    toast.success("Status updated Successfully!")
  } catch (error) {
    console.error("Error updating Razorpay status:", error);
  }
  };

  console.log("Id @#$12",id)

// const handleUpdateKey = async () => {
//     setIsLoading(true)
//   try {
//     const formData = new FormData();
//     formData.append("id", id);
//     formData.append("public_key", publicKey);
//     formData.append("secret_key", secretKey);

//     await postData("/update_payment_gateway", formData);
//     toast.success("Key updated Successfully!")
//   } catch (error) {
//     console.log("Error updating Razorpay keys", error);
//   } finally{
//     setIsLoading(false)
//   }
// };

const handleUpdateKey = async () => {
  setIsLoading(true);
  try {
    const formData = new FormData();
    formData.append("id", id);
    formData.append("public_key", publicKey);
    formData.append("secret_key", secretKey);

    await postData("/update_payment_gateway", formData);
    fetchPaymentDetails()
    toast.success("Key updated Successfully!");

    // Reset masking
    setEditedPublicKey(false);
    setEditedSecretKey(false);
  } catch (error) {
    console.log("Error updating Razorpay keys", error);
  } finally {
    setIsLoading(false);
  }
};

  return (
    <>
      {/* Toggle Switch */}
      <div className='flex justify-between p-4 text-sm border rounded-lg font-poppins dark:border-[#1F1F1F] dark:text-darkText border-opacity-gradient'>
        Enable PayPal Payment
        <label className="flex items-center cursor-pointer select-none">
          <div className="relative">
            <input
              type="checkbox"
              checked={status === "1"}
              onChange={handleToggle}
              className="sr-only"
            />
            <div
              className={`block h-6 w-10 rounded-full border transition duration-300 ${
                status === "1" ? "bg-header border-header" : "bg-transparent border-header"
              }`}
            ></div>
            <div
              className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                status === "1" ? "right-1 bg-white" : "left-1 bg-header"
              }`}
            ></div>
          </div>
        </label>
      </div>

      {/* Input Fields */}
      <div className='grid grid-cols-2 gap-4 py-5'>
        <div>
          <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
            PayPal Public Key
          </label>
      

          <input
            type="text"
            placeholder="Enter PayPal Public Key"
            value={
              editedPublicKey ? publicKey : "*".repeat(publicKey?.length || 0)
            }
            onChange={(e) => {
              setEditedPublicKey(true);
              setPublicKey(e.target.value);
            }}
            className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
          />
        </div>

        <div>
          <label className="text-[#000000] font-poppins font-semibold text-sm dark:text-darkText">
            PayPal Secret Key
          </label>
          <input
            type="text"
            placeholder="Enter PayPal Secret Key"
            value={
              editedPublicKey ? secretKey : "*".repeat(secretKey?.length || 0)
            }
            onChange={(e) => {
              setEditedSecretKey(true);
              setSecretKey(e.target.value);
            }}
            className="border border-opacity-gradient rounded-md w-full py-3 my-1 px-4 dark:bg-transparent dark:text-darkText dark:border-borderColor placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
          />
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-center pt-6 pb-4 place-items-center">
        <button
          className={`w-[260px] py-3 text-lg font-medium font-poppins rounded-xl transition-opacity bg-button-gradient text-[#FFFFFF]`}
          onClick={handleUpdateKey}
        >
            {isLoading ? (<>
             <ClipLoader
        loading={loading}
        size={20}
        aria-label="Loading Spinner"
        data-testid="loader"
        color='#FFFFFF'
      />
            </>) : (<>Submit</>)}
        </button>
      </div>
    </>
  );
}

export default PayPal;
