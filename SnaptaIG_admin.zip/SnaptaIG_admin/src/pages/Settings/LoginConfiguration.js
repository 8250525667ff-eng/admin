import React, { useState, useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import useApiPost from "../hooks/postData";
import { ClipLoader } from "react-spinners";
import { FaInfoCircle } from "react-icons/fa";

function LoginConfiguration() {
  const [option, setOption] = useState("User");
  const [toggleStates, setToggleStates] = useState(1);

  const [loginData, setLoginData] = useState([]);
  const { data, loading, postData } = useApiPost();
  const [isLoading, setIsLoading] = useState(false);

  const fetchLoginDetails = async () => {
  
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/admin_all_login_status`
      );
      setLoginData(response.data.data); // ✅ This sets only the array part
    } catch (err) {
      console.error("Failed to fetch admin login details", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLoginDetails();
  }, []);
  const SocialData = loginData?.normal_data;

  const NormalData = loginData?.admin_data;
  console.log("Login Data @#12", NormalData);

 const handleToggle = async (id, currentStatus) => {
  const newStatus = currentStatus === "1" ? "0" : "1";
  try {
    const formData = new FormData();
    formData.append("id", id);
    formData.append("status", newStatus);

    await postData("/update_login_status", formData);

    // Update local state properly depending on which array the id belongs to
    setLoginData((prev) => {
      const updateList = (list) =>
        list.map((item) =>
          item.id === id ? { ...item, status: newStatus } : item
        );

      return {
        ...prev,
        normal_data: updateList(prev.normal_data),
        admin_data: updateList(prev.admin_data),
      };
    });
    fetchLoginDetails()
    toast.success("Status updated successfully");
  } catch (error) {
    console.error("Error updating status:", error);
  }
};


  return (
    <>
      <h2 className="text-[#000000] font-semibold font-poppins text-xl dark:text-darkText pb-4 pt-6 sm:pt-0">
        Login Configuration
      </h2>
      {/* Options open */}
      {isLoading ? (
        <>
          <div className="flex justify-center py-40 place-items-center">
            <ClipLoader
              loading={isLoading}
              size={20}
              aria-label="Loading Spinner"
              data-testid="loader"
              color="#452B7A"
            />
          </div>
        </>
      ) : (
        <>
          <div className="flex flex-col gap-3 px-6 py-4 font-poppins">
            <span>
            <h2 className="text-[#000000] font-poppins dark:text-darkText font-semibold">Normal Login</h2>
            <p className="flex gap-1 text-sm font-poppins place-items-center dark:text-darkText">(<FaInfoCircle className="w-4 h-4"/> - You can disable only 1 option)</p>
            </span>

            {/* Email */}
            <div className="flex justify-between border border-opacity-gradient dark:text-darkText dark:border-[#1F1F1F] p-5 rounded-xl text-base">
              Email
              {NormalData?.length > 0 && <div className="ml-auto">
                  <label className="flex items-center cursor-pointer select-none">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={NormalData[0]?.status === "1"}
                        onChange={() => handleToggle(NormalData[0]?.id, NormalData[0]?.status)}
                        className="sr-only"
                      />

                      {/* Toggle Background */}
                      <div
                        className={`block h-6 w-10 rounded-full border transition duration-300 ${
                          NormalData[0]?.status === "1"
                            ? "bg-header border-header"
                            : "bg-transparent border-header"
                        }`}
                      ></div>

                      {/* Toggle Dot */}
                      <div
                        className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                          NormalData[0]?.status === "1"
                            ? "right-1 bg-white"
                            : "left-1 bg-header"
                        }`}
                      ></div>
                    </div>
                  </label>
                </div> }
            </div>

            {/* MobileOtp */}
            <div className="flex justify-between border border-opacity-gradient dark:text-darkText dark:border-[#1F1F1F] p-5 rounded-xl text-base">
              MobileOtp
              {NormalData?.length > 0 && <div className="ml-auto">
                  <label className="flex items-center cursor-pointer select-none">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={NormalData[1]?.status === "1"}
                        onChange={() => handleToggle(NormalData[1]?.id, NormalData[1]?.status)}
                        className="sr-only"
                      />

                      {/* Toggle Background */}
                      <div
                        className={`block h-6 w-10 rounded-full border transition duration-300 ${
                          NormalData[1]?.status === "1"
                            ? "bg-header border-header"
                            : "bg-transparent border-header"
                        }`}
                      ></div>

                      {/* Toggle Dot */}
                      <div
                        className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                          NormalData[1]?.status === "1"
                            ? "right-1 bg-white"
                            : "left-1 bg-header"
                        }`}
                      ></div>
                    </div>
                  </label>
                </div> }
            </div>

            <span>
            <h2 className="text-[#000000] font-poppins dark:text-darkText font-semibold pt-4">Social Login</h2>
            <p className="flex gap-1 text-sm font-poppins place-items-center dark:text-darkText">(<FaInfoCircle className="w-4 h-4"/> - You can disable all options)</p>
            </span>
            
            {/* Facebook */}
            <div className="flex justify-between border border-opacity-gradient dark:text-darkText dark:border-[#1F1F1F] p-5 rounded-xl text-base">
              Facebook 
              {/* Toggle button */}
              {SocialData?.length > 0 && <div className="ml-auto">
                  <label className="flex items-center cursor-pointer select-none">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={SocialData[0]?.status === "1"}
                        onChange={() => handleToggle(SocialData[0]?.id, SocialData[0]?.status)}
                        className="sr-only"
                      />

                      {/* Toggle Background */}
                      <div
                        className={`block h-6 w-10 rounded-full border transition duration-300 ${
                          SocialData[0]?.status === "1"
                            ? "bg-header border-header"
                            : "bg-transparent border-header"
                        }`}
                      ></div>

                      {/* Toggle Dot */}
                      <div
                        className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                          SocialData[0]?.status === "1"
                            ? "right-1 bg-white"
                            : "left-1 bg-header"
                        }`}
                      ></div>
                    </div>
                  </label>
                </div> }
            </div>

            {/* Google */}
            <div className="flex justify-between border border-opacity-gradient dark:text-darkText dark:border-[#1F1F1F] p-5 rounded-xl text-base">
              Google 
              {/* Toggle button */}
              {SocialData?.length > 0 && <div className="ml-auto">
                  <label className="flex items-center cursor-pointer select-none">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={SocialData[1]?.status === "1"}
                        onChange={() => handleToggle(SocialData[1]?.id, SocialData[1]?.status)}
                        className="sr-only"
                      />

                      {/* Toggle Background */}
                      <div
                        className={`block h-6 w-10 rounded-full border transition duration-300 ${
                          SocialData[1]?.status === "1"
                            ? "bg-header border-header"
                            : "bg-transparent border-header"
                        }`}
                      ></div>

                      {/* Toggle Dot */}
                      <div
                        className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                          SocialData[1]?.status === "1"
                            ? "right-1 bg-white"
                            : "left-1 bg-header"
                        }`}
                      ></div>
                    </div>
                  </label>
                </div> }
                
              
            </div>

            {/* Apple */}
            <div className="flex justify-between border border-opacity-gradient dark:text-darkText dark:border-[#1F1F1F] p-5 rounded-xl text-base">
              Apple 
              {/* Toggle button */}
              {SocialData?.length > 0 && <div className="ml-auto">
                  <label className="flex items-center cursor-pointer select-none">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={SocialData[0]?.status === "1"}
                        onChange={() => handleToggle(SocialData[2]?.id, SocialData[2]?.status)}
                        className="sr-only"
                      />

                      {/* Toggle Background */}
                      <div
                        className={`block h-6 w-10 rounded-full border transition duration-300 ${
                          SocialData[2]?.status === "1"
                            ? "bg-header border-header"
                            : "bg-transparent border-header"
                        }`}
                      ></div>

                      {/* Toggle Dot */}
                      <div
                        className={`absolute top-1 h-4 w-4 rounded-full transition duration-300 ${
                          SocialData[2]?.status === "1"
                            ? "right-1 bg-white"
                            : "left-1 bg-header"
                        }`}
                      ></div>
                    </div>
                  </label>
                </div> }
                
              
            </div>

            {/* Social Data */}
            


            
          </div>
        </>
      )}
    </>
  );
}

export default LoginConfiguration;
