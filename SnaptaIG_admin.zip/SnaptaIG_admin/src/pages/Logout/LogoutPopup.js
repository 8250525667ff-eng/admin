import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Cookies from 'js-cookie'
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import Logout from '../../assets/logout.png'
import '../PostList/style.css'
import { useTheme,setTheme } from "../../context/ThemeProvider";

function DialogBox({ open, handleClose, handleDelete }) {

    const { resetTheme } = useTheme()
    const navigate = useNavigate()
    const handleLogout = () => {
        Cookies.remove("token")
        toast.success("Logged out Successfully!")
        resetTheme()
        navigate("/signin")

    }
    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="custom-dialog" >
            <DialogContent className="flex flex-col items-center text-center dark:bg-primary">
                {/* Delete Icon */}
                <div className="flex justify-center p-2 rounded-full 2xl:p-4 bg-opacityGradient dark:bg-purple-300">
                    <img src={Logout} alt="delete" className="w-11 h-11" />
                </div>

                {/* Confirmation Text */}
           <h2 className="text-xl font-poppins text-[#000000] mt-4 dark:text-darkText">Are you sure you want to logout?</h2>
            </DialogContent>
            
            <DialogContent className="flex justify-center gap-4 pb-4 dark:bg-primary">
                <div className="flex justify-center gap-3">
                    <button className="px-20 py-2 rounded-lg border border-header text-[#3A3333] font-medium dark:text-darkText" onClick={handleClose}>
                        Cancel
                    </button>
                    <button onClick={handleLogout} className="px-20 py-2 font-medium text-white rounded-lg bg-button-gradient">
                        Logout
                    </button>
                </div> 
            </DialogContent>
        </Dialog>
    );
}

export default DialogBox;
