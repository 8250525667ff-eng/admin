import React, { useState } from "react";
import Delete from '../../assets/delete.png';
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Loader from '../../assets/Loader.gif'
import '../../components/DialogBoxCustom.css'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";

function AddHashtag({ open, handleClose, handleDelete }) {
    const {data,error,postData,loading} = useApiPost();
    const [text,setText] = useState("")
    const handleAddHashtag = () => {
        try{
            const response = postData("/add_hashtag",{text:text})
            toast.success("Hashtag Added successfully!")
            handleDelete()
            handleClose()
        }catch(error){

        }
    }

    console.log("Text !!!",text)
    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="p-0 hashtag-dialog" >
            <DialogTitle className="flex justify-center text-base font-bold text-[#000000] font-poppins dark:bg-primary bg-[#FFFFFF] shadow-lg light:rounded-lg dark:text-darkText">Add Hashtag</DialogTitle>
           
            <button onClick={handleClose} className="absolute text-2xl text-gray-600 dark:text-white top-2 right-2">
                 ×
            </button>
            <DialogContent className="flex flex-col mx-5 dark:mx-0 dark:bg-primary">
                {/* Delete Icon */}
                <h2 className="text-base font-poppins text-[#000000] pt-4 font-semibold dark:text-darkText">Hashtag Name</h2>
                <input type="text" placeholder="Enter Hashtag Name"
                className="border border-opacity-gradient rounded-lg dark:bg-transparent dark:border-[#1F1F1F] placeholder:text-tableDarkLarge text-darkText w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                onChange={(e) => setText(e.target.value)}/>
                <div className="flex justify-center py-6">
                    <button className="w-[250px] py-3 font-medium text-white rounded-xl bg-button-gradient" onClick={handleAddHashtag}>
                        {loading ? (<>
                        <div className='flex justify-center py-2'><img src={Loader} alt="loader" height={16} width={16}/></div>
                        </>) : (<>Submit</>)}
                    </button>
                </div>
            </DialogContent>
         
        </Dialog>
    );
}

export default AddHashtag;
