import React,{useState,useEffect,useRef} from 'react';
import Search from '../../assets/search.png';
import Searchbar from '../../components/Search';
import Dropdown from '../../assets/dropdown.png';
import { Link } from 'react-router-dom';
import Arrow from '../../assets/Showing_Arrow.png'
import AddHashtag from './AddHashtagListDialog';
import Add from '../../assets/add.png'
import useApiPost from '../hooks/postData';
import DeactiveArrow from '../../assets/deactive_Arrow.png'
import Loader from '../../assets/Loader.gif'
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import NoData from '../../assets/NoData.png'

function PostList() {
  // Sample data for posts
  const [activePage,setActivePage] = useState(1)
  const [isLoading,setIsLoading] = useState(false)
  const [order,setOrder] = useState("")
  const [category,setCategory] = useState("")
  const {data,error,refetch,postData} = useApiPost()
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState("10");
  const dropdownRef = useRef(null);
  const [search,setSearch] = useState("")
  const navigate = useNavigate()

// Options for dropdown
const options = ["10", "25", "50","100"];

// Function to handle option selection
const handleSelect = (value) => {
  setSelectedValue(value);
  setIsDropdownOpen(false);
  setActivePage(1)
};

// To get HashtagList 
const handleGetHashtagList = async() => {
  setIsLoading(true)
  try{
    const PageNo = selectedValue!=10 ? 1 : activePage
    const response = await postData("/get_all_hashtag_pagination",{page_no:PageNo,per_page:selectedValue,order:order,category:category,search:search})
  } catch(error){
  } finally{
    setIsLoading(false)
  }
}

useEffect(() => {
  handleGetHashtagList()
}, [activePage,selectedValue,order,category,search]);

const ActivePage = data?.tag_users
console.log("Post @@@ !!!",ActivePage)

const pagination = data?.pagination;
const lastPage = pagination?.last_page || 1;
const currentPage = pagination?.current_page
const AllHashtagList = data?.tag_users || [];

// Close dropdown if clicked outside
useEffect(() => {
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsDropdownOpen(false);
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, []);

// To open Add Hashtag Dialog
const [open,setOpen] = useState(false)
const handleOpen = () => { setOpen(true) }
const handleClose = () => 
  { 
    setOpen(false) 
  }
  const handleDelete = async() => {
    await handleGetHashtagList()
  }



  const handleRefetch = async () => {
    await handleGetHashtagList(); // Refetch post list
  };

  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);

  return (
    <>
    {/* <div className="mb-10 xl:pl-72"> */}
    <div className={`dark:bg-primary ${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
      <Searchbar />
      <div className='px-4 pb-10 xl:px-6'>
      
      {/* Title */}
      <div className="flex justify-between border-t-[#F2F2F2] py-3 ">
        <h2 className="text-[#000000] dark:text-darkText font-poppins text-xl font-semibold pt-3">Hashtag List</h2>
        {/* Add Hashtag button */}
        <button className='flex gap-1.5 place-items-center px-4 text-sm font-poppins font-medium text-[#FFFFFF] rounded-md bg-button-gradient' onClick={handleOpen}>
          <img src={Add} className='w-4 h-4' />
          <p>Add Hashtag</p>
        </button>
      </div>

      {/* Navigation Path */}
      <div className="flex items-center justify-between ">
        <div className="flex items-center gap-2">
          <Link to="/dashboard"><h3 className="text-[#3A3A3A] dark:text-darkText font-poppins text-base font-semibold">Dashboard</h3></Link>
          <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
          <h3 className="text-[#858585] font-poppins text-base">Hashtag List</h3>
        </div>
        {/* Search by username */}
        <div className="relative hidden md:block">
          <div className="absolute flex items-center p-2 transform -translate-y-1/2 left-2 top-1/2">
            <img src={Search} alt="Search" className="w-5 h-5" />
          </div>
          <input
            type="text"
            className="border border-gray-500 bg-[#00000005] w-[180px] dark:text-darkText placeholder:dark:text-tableDarkLarge border-opacity-10 rounded-lg md:w-[250px] py-2 pl-12 placeholder:text-sm placeholder:text-[#0000004F] focus:outline-none focus:ring-1 focus:ring-gray-600"
            placeholder="Search by Hashtag Word..."
            onChange={(e) => setSearch(e.target.value)}
            value={search}
          />
        </div>
      </div>

      {/* Search field for phone screen */}  
      <div className='block gap-4 pt-4 md:hidden'>
        {/* search hashtag */}
        <div className="relative">
          <div className="absolute flex items-center p-2 transform -translate-y-1/2 left-2 top-1/2">
            <img src={Search} alt="Search" className="w-4 h-4 md:w-5 md:h-5" />
          </div>
          <input
            type="text"
            className="border border-gray-500 bg-[#00000005] w-full dark:text-darkText placeholder:dark:text-tableDarkLarge border-opacity-10 rounded-lg md:w-[250px] py-2 md:pl-12 pl-10 md:placeholder:text-sm placeholder:text-xs placeholder:text-[#0000004F] focus:outline-none focus:ring-1 focus:ring-gray-600"
            placeholder="Search by Hashtag Word..."
            onChange={(e) => setSearch(e.target.value)}
            value={search}
          />
        </div>
      </div>

      {/* Header Bar */}
    <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg mt-8 overflow-x-auto w-full">
      <div className='xl:overflow-x-auto lg:overflow-x-auto 2xl:overflow-hidden min-w-[1200px] '>
      <div className='min-w-max'> 
 
  {/* Table Header */}
  <div className="flex px-4 py-3 pl-16 text-left border-b dark:border-b-[#1F1F1F] dark:bg-darkHeader bg-header1">
    <div className="w-[50%] text-headerText font-poppins text-sm font-semibold">S.L </div>
    <div className="w-[65%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">HASHTAG WORD 
      <div className='flex flex-col'>
            <button onClick={() => { setOrder("0"); setCategory("Text"); }}>
              <img src={category === "Text" && order==="0" ? Dropdown : DeactiveArrow} className={`w-2 h-2 rotate-180 transition`} />
            </button>
            <button onClick={() => { setOrder("1"); setCategory("Text"); }}>
              <img src={category === "Text" && order === "1" ? Dropdown : DeactiveArrow} className={`w-2 h-2 transition`} />
            </button>
      </div>
    </div>
    <div className="w-[65%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">POST COUNT 
    <div className='flex flex-col'>
            <button onClick={() => { setOrder("0"); setCategory("PostCount"); }}>
              <img src={category === "PostCount" && order==="0" ? Dropdown : DeactiveArrow} className={`w-2 h-2 rotate-180 transition`} />
            </button>
            <button onClick={() => { setOrder("1"); setCategory("PostCount"); }}>
              <img src={category === "PostCount" && order === "1" ? Dropdown : DeactiveArrow} className={`w-2 h-2 transition`} />
            </button>
      </div>
    </div>
    <div className="w-[65%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">REEL COUNT 
    <div className='flex flex-col'>
            <button onClick={() => { setOrder("0"); setCategory("ReelCount"); }}>
              <img src={category === "ReelCount" && order==="0" ? Dropdown : DeactiveArrow} className={`w-2 h-2 rotate-180 transition`} />
            </button>
            <button onClick={() => { setOrder("1"); setCategory("ReelCount"); }}>
              <img src={category === "ReelCount" && order === "1" ? Dropdown : DeactiveArrow} className={`w-2 h-2 transition`} />
            </button>
      </div>
    </div>
  </div>

  {/* Data Rows */}
  {isLoading ? (<div className='flex justify-center py-60'><img src={Loader} alt="loader" height={50} width={50}/></div>) : 
   (<>
   {AllHashtagList?.length > 0 ? 
   
   (<>
    {AllHashtagList?.map((hashtag, index) => (
    <div key={hashtag.id} className={`${index % 2 === 0 ? 'bg-white dark:bg-primary' : 'bg-[#00162e0a] dark:bg-primary'} flex dark:border-b-[#1F1F1F] items-center px-4 py-3 pl-16 border-b last:border-0`}>

      {/* Serial Number */}
      <div className="w-[50%] text-[#000000] dark:text-darkText font-poppins text-sm">{(currentPage - 1) * selectedValue + index + 1}</div>

      {/* Hashtag Word */}
      <div className="w-[65%]">
        <h2 className='font-poppins text-[#333333] dark:text-darkText text-sm'>#{hashtag.text}</h2>
      </div>

      {/* count */}
      <div className="w-[65%] flex gap-2 items-center">
        <p className='text-[#414141] font-poppins dark:text-tableDarkLarge text-sm'>{hashtag.post_hashtag_count} post</p>
      </div>

      {/* created date */}
      <div className="w-[65%]">
        <h2 className="text-[#414141] font-poppins dark:text-tableDarkLarge text-sm">{hashtag.reel_hashtag_count} reel</h2>
      </div>
    </div>
  ))} 
   </>) : 
   
   (<>
    <div className='flex flex-col justify-center py-32 2xl:py-36 place-items-center'>
        <img src={NoData} alt="no data" className='w-96' />
        <h2 className='font-poppins text-[#000000] text-sm font-semibold'>Don't have any data to show</h2>
       </div>
   </>)}
     
   </> )}
  


  {/* Pagination and Results Count */}
  {AllHashtagList?.length > 0 && 
  <div className="flex justify-between px-10 py-6 bg-white dark:bg-primary">
  {/* Results Count */}
  <div className="relative flex gap-2 place-items-center" ref={dropdownRef}>
    {/* Dropdown Button */}
    <div
      className="border border-[#9C9C9C] dark:bg-primary bg-[#edeff166] dark:border-[#1F1F1F] rounded-xl flex gap-2 items-center px-3 py-1 cursor-pointer relative"
      onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
      <p className="text-[#00162e] font-poppins dark:text-darkText">{selectedValue}</p>
      <button>
        <img src={Arrow} className="w-4 h-4" />
      </button>
    </div>
  
    {/* Dropdown Menu - Positioned Above */}
    {isDropdownOpen && (
      <div className="absolute left-0 z-50 mb-2 bg-white border border-gray-300 dark:border-[#1F1F1F] rounded-lg shadow-lg dark:bg-primary bottom-full w-max">
        {options.map((option) => (
          <p
            key={option}
            className="px-4 py-2 text-sm cursor-pointer hover:bg-gray-100 dark:text-darkText"
            onClick={() => handleSelect(option)}>
            {option}
          </p>
        ))}
      </div>
    )}
  
    {/* Results Text */}
    <p className="text-[#333333] font-poppins text-sm dark:text-gray-600">
      Showing <span className="font-semibold text-[#000000] dark:text-darkText text-sm">{pagination?.total}</span> results
    </p>
  </div>
  
      {/* Pagination Buttons */}
  
    
<div className="flex items-center">
  {/* Previous Button */}
  <button 
    className={`text-[#000000] dark:text-darkText text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
      ${pagination?.prev_page === 0 ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-200"}`}
    onClick={() => setActivePage(prev => (prev > 1 ? prev - 1 : prev))}
    disabled={pagination?.prev_page === 0}
  >
    Previous
  </button>

  {/* Page Numbers */}
  {[...Array(lastPage)].map((_, index) => {
    const page = index + 1;

    const shouldRender =
      page === activePage ||
      page === activePage + 1 ||
      page === lastPage - 1 ||
      page === lastPage;

    if (!shouldRender) return null;

    // Add ellipses after activePage + 1, if gap exists before lastPage -1
    if (page === activePage + 1 && lastPage - 1 > activePage + 1) {
      return (
        <React.Fragment key={page}>
          <button 
            className={`text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
              ${activePage === page ? "text-white bg-button-gradient" : "text-black dark:text-darkText hover:bg-gray-200"}`}
            onClick={() => setActivePage(page)}
          >
            {page}
          </button>
          <span className="px-2 select-none">...</span>
        </React.Fragment>
      );
    }

    return (
      <button 
        key={page} 
        className={`text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
          ${activePage === page ? "text-white bg-button-gradient" : "text-black dark:text-darkText hover:bg-gray-200"}`}
        onClick={() => setActivePage(page)}
      >
        {page}
      </button>
    );
  })}

  {/* Next Button */}
  <button 
    className={`text-[#000000] dark:text-darkText text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
      ${pagination?.next_page > lastPage ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-200"}`}
    onClick={() => setActivePage(prev => (prev < lastPage ? prev + 1 : prev))}
    disabled={pagination?.next_page > lastPage}
  >
    Next
  </button>
</div>
  
    </div> }
      </div>

      </div> 
      </div>
      </div>
    </div>
    <AddHashtag open={open} handleClose={handleClose} handleDelete={handleDelete}   />
    </>
  );
}

export default PostList;






