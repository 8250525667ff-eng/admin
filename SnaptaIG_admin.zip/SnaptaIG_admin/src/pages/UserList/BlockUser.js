import React, { useState } from "react";
import Delete from '../../assets/delete.png';
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import '../ReelList/style.css'
import './style.css' 
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import { MdBlockFlipped } from "react-icons/md";
import Loader from '../../assets/Loader.gif'


function BlockUser({ open, handleClose, handleDelete, UserID, UserStatus }) {
  const { postData,loading } = useApiPost();

  const handleUserToggle = async () => {
    try {
      const response = await postData("/user_edit_status", { to_user_id: UserID });

      if (response?.status === "success") {
        const newStatus = UserStatus === "1" ? "0" : "1";
        toast.success(
          newStatus === "1" ? "User Activated Successfully!" : "User Deactivated Successfully!"
        );
        handleDelete(newStatus); // tell parent to update Redux
        handleClose();
      } else {
        toast.error("Failed to update user status");
      }
    } catch (error) {
      toast.error("Something went wrong");
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} fullWidth className="custom-dialog">
      <DialogContent className="flex flex-col items-center text-center dark:bg-primary">
        <div className="flex justify-center p-2 rounded-full bg-opacityGradient">
          <MdBlockFlipped className="w-7 h-7 text-sidebarText" />
        </div>
        <h2 className="text-xl font-poppins text-[#000000] mt-4 dark:text-darkText">
          Are you sure you want to {UserStatus === "0" ? "Activate" : "Deactivate"} this user?
        </h2>
      </DialogContent>
      <DialogContent className="flex justify-center gap-4 pb-4 overflow-x-hidden dark:bg-primary">
        <button
          className="w-[220px] py-2 border dark:text-darkText border-header text-[#3A3333] rounded-lg"
          onClick={handleClose}
        >
          Cancel
        </button>
        <button
          onClick={handleUserToggle}
          className="w-[220px] py-2 text-white rounded-lg  bg-button-gradient"
        >
          {loading ? (<>
           <div className='flex justify-center py-2'><img src={Loader} alt="loader" height={10} width={10}/></div>
          </>) : 
          
          (<>
            {UserStatus === "0" ? "Activate" : "Deactivate"}
          </>)}
        </button>
      </DialogContent>
    </Dialog>
  );
}


export default BlockUser;