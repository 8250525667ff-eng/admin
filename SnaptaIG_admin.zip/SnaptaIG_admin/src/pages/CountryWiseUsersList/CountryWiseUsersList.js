import React,{useEffect} from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, Cell } from "recharts";
import Cookies from 'js-cookie';
import { useGetCountryWiseUserQuery } from "../../store/api/CountryWiseUserDashboard";
import Loader from '../../assets/Loader.gif'
import { Link } from "react-router-dom";
import Add from '../../assets/add.png'
import { useSelector } from "react-redux";
import Searchbar from '../../components/Search'
import { useTheme } from "../../context/ThemeProvider";
import { useNavigate } from "react-router-dom";
import NoData from '../../assets/NoData.png'

const COLORS = ["#46BFDA", "#3DD0B7", "#F3CC5C", "#59A7FF"];

function UsersByCountry() {
  const token = Cookies.get("Snapta_Admin_Token");
  const { data: countryData, isLoading } = useGetCountryWiseUserQuery({ token });
  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);
  const {theme} = useTheme()

  const data = (countryData?.data?.map((item) => ({
    country: item.country,
    users: item.total_users,
  })) || []).sort((a, b) => b.users - a.users);


  
  // Get the sum of all total_users
  const TotalUsers = countryData?.data?.reduce((sum, item) => sum + item.total_users, 0) || 0;
  console.log("Total Users:", TotalUsers);
  

  const chartHeight = data.length * 60; // 60px per bar for spacing
  
   if (isLoading || !countryData) {
      return (
        <div className="border border-[#D1D5DB] dark:border-[#1F1F1F] rounded-lg p-4 w-full h-[440px] flex items-center justify-center">
          <img src={Loader} className="w-12 h-12" alt="Loading..." />
        </div>
      );
    }
    const isDark = theme === "dark";

    const barBgColor = isDark ? "#1F1F1F" : "#E5E7EB"; // background of the bar
    const countryTextColor = isDark ? "#E5E7EB" : "#4B5563"; // country name
    const userValueColor = isDark ? "#F9FAFB" : "#111827"; // value number

    console.log("Country Length 123@#",countryData?.data.length)
    
  return (
    <div className={`dark:bg-primary ${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
        <Searchbar />

        <div className="mx-4 xl:mx-6">
         {/* Title */}
         <div className="flex justify-between border-t-[#F2F2F2]  py-3">
        <h2 className="text-[#000000] font-poppins text-xl font-semibold pt-3 dark:text-darkText">Country Wise Users</h2>
      </div>

      {/* Navigation Path */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/dashboard"><h3 className={`text-[#3A3A3A] font-poppins text-base font-semibold dark:text-darkText`}>Dashboard</h3></Link>
          <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
          <h3 className="text-[#858585] font-poppins text-base">Country Wise Users</h3>
        </div>
      </div>

      {countryData?.data.length > 0 ? 
      
      (<>
        <div className="w-full mt-5 border-[#D1D5DB] rounded-lg py-2 dark:border-[#1F1F1F] border" style={{ height: `${chartHeight}px` }}>
  <ResponsiveContainer width="100%" height="100%">
    <BarChart
      layout="vertical"
      data={data}
      margin={{ top: 30, right: 50, left: 20, bottom: 20 }}
      barSize={12} // optional: reduce/increase bar thickness
    >
      
      <XAxis type="number"  domain={[0, TotalUsers]} hide />

      <Bar
        dataKey="users"
        background={{ fill: barBgColor, radius: [10, 10, 10, 10] }}
        radius={[10, 10, 10, 10]}
        label={({ x, y, width, height, value, index }) => {
          const country = data[index].country;
          return (
            <g>
              <text
                x={x}
                y={y + height / 2 - 12}
                fontSize="14"
                fill={countryTextColor}
                fontFamily="Poppins"
              >
                {country}
              </text>
              <circle
                cx={x + width}
                cy={y + height / 2}
                r={6}
                fill={COLORS[index % COLORS.length]}
                stroke="#fff"
                strokeWidth={2}
              />
              <text
                x={x + width + 10}
                y={y + height / 2 + 5}
                fontSize="12"
                fill={userValueColor}
                fontFamily="Poppins"
                textAnchor="start"
              >
                {value} Users
              </text>
            </g>
          );
        }}
      >
        {data.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
        ))}
      </Bar>
    </BarChart>
  </ResponsiveContainer>
      </div>
      </>) : 
      
      (<>
       <div className='flex flex-col justify-center py-32 2xl:py-36 place-items-center'>
    <img src={NoData} alt="no data" className='w-96' />
    <h2 className='font-poppins text-[#000000] text-sm font-semibold'>Don't have any data to show</h2>
   </div>
      </>)}

     

      </div>

    </div>
  );
}

export default UsersByCountry;
