import React, { useEffect, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import '../../components/DialogBoxCustom.css'
import Arrow from '../../assets/languageArrow.png'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";

function EditLanguage({ open, handleClose,statusID,LanguageName }) {

    const {data,error,postData} = useApiPost()
    const [languageName,setLanguageName] = useState("")
    const [languageAlignment,setLanguageAlignment] = useState()
    const [showDropdown, setShowDropdown] = useState(false);

    const toggleDropdown = () => {
        setShowDropdown((prev) => !prev);
    };

    const handleSelectAlignment = (value) => {
        setLanguageAlignment(value);
        setShowDropdown(false);
    };
    
    const handleEditLanguage = () => {
        const response = postData("/editLanguage",{status_id:statusID,language_name:languageName,language_alignment:languageAlignment})
        handleClose()
        toast.success("Language Edit Successfull")
    }

    console.log("Status Id !!!",LanguageName)
    
    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="hashtag-dialog" >
            <DialogTitle className="flex justify-center text-base font-bold text-[#000000] font-poppins dark:text-darkText dark:bg-primary bg-[#FFFFFF] shadow-lg light:rounded-lg">Edit Language</DialogTitle>
            {/* <img src={Cross} className="absolute w-8 h-8 cursor-pointer top-4 right-2" onClick={handleClose} /> */}
            <button onClick={handleClose} className="absolute text-2xl text-gray-600 dark:text-white top-2 right-2">
                 ×
            </button>
            <DialogContent className="flex flex-col light:mx-5 dark:bg-primary">
                {/* Language Name Input*/}
                <h2 className="text-base font-poppins text-[#000000] pt-4  font-semibold dark:text-darkText">Language Name</h2>
                <input type="text" placeholder="Enter Language Name"
                className="border border-opacity-gradient dark:bg-transparent dark:border-[#1F1F1F] dark:text-darkText dark:placeholder:text-tableDarkLarge rounded-lg w-full py-3 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                onChange={(e) => setLanguageName(e.target.value)} 
                value={languageName || LanguageName}/>

                {/* Text Direction Input */}
                <h2 className="text-base font-poppins text-[#000000] pt-4 font-semibold dark:text-darkText">Text Direction</h2>
                

                <div className="relative z-50">
  <div
    className="w-full h-12 px-4 py-3 pr-10 my-1 text-[#000000] text-sm bg-white dark:bg-transparent dark:border-[#1F1F1F] dark:text-darkText dark:placeholder:text-tableDarkLarge border rounded-lg cursor-pointer border-opacity-gradient focus:outline-none focus:ring-1 focus:ring-header"
    onClick={toggleDropdown}
  >
    {languageAlignment || "Left to Right(LTR)"}
  </div>
  <img
    src={Arrow}
    alt="arrow"
    className="absolute w-3 h-3 transform -translate-y-1/2 cursor-pointer right-4 top-1/2"
    onClick={toggleDropdown}
  />
  {showDropdown && (
    <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 dark:bg-[#1F1F1F] dark:border-[#1F1F1F] dark:text-darkText dark:placeholder:text-tableDarkLarge rounded-lg shadow-md">
      <div className="px-4 py-2 text-sm cursor-pointer light:hover:bg-gray-100" onClick={() => handleSelectAlignment("Left to Right(LTR)")}>Left to Right(LTR)</div>
      <div className="px-4 py-2 text-sm cursor-pointer light:hover:bg-gray-100" onClick={() => handleSelectAlignment("Right to Left(RTL)")}>Right to Left(RTL)</div>
    </div>
  )}
</div>


                {/* Submit button */}
                <div className="flex justify-center py-6">
                    <button className="px-20 py-3 font-medium text-white rounded-xl bg-button-gradient" onClick={handleEditLanguage}>
                        Submit
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default EditLanguage;








