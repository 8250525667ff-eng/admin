import React, { useEffect,useRef,useState } from "react";
import Searchbar from '../../components/Search'
import Arrow from '../../assets/Showing_Arrow.png'
import { Link } from "react-router-dom";
import useApiPost from "../hooks/postData";
import { useLocation } from "react-router-dom";
import toast from "react-hot-toast";
import axios from "axios";
import Loader from '../../assets/Loader.gif'

function Translate() {

    const {data,error,postData,loading} = useApiPost()
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [selectedValue, setSelectedValue] = useState("10");
    const [activePage,setActivePage] = useState(1)
    const dropdownRef = useRef(null);
    const [Value,setValue] = useState("")
    const [valueMap,setValueMap] = useState("")
    const location = useLocation().pathname.split("/")
    console.log("Location !!!",location[2])
    const statusId = location[2]
    const [Data,setData] = useState("")
    
    // options for dropdown
    const options = ["10", "25", "50","100"];
    
    // Function to handle option selection
    const handleSelect = (value) => {
    setSelectedValue(value);
    setIsDropdownOpen(false);
    setActivePage(1)
    };

    //fetch all key value
    const handleFetchLanguage = async() => {
        try{
            const PageNo = selectedValue!=10 ? 1 : activePage
            const response = await axios.post("http://145.223.23.5/api/fetchLanguageKeywordsWithTranslation",{status_id:statusId,page_no:PageNo,per_page:selectedValue})
            setData(response?.data)
        } catch(error){ }
    }
   
    const pagination = Data?.pagination;
    const lastPage = pagination?.totalPages
    const currentPage = pagination?.currentPage
    const totalPages = pagination?.totalPages

    // ==========================================================

    useEffect(() => {
        handleFetchLanguage()
    },[statusId,selectedValue,activePage,valueMap])

    // handle translate of 1 keyword 
    const handleTranslateOneKeyword = (settingId) => {
        const newValue = valueMap[settingId] ?? "";
        try {
          postData("/translateoneKeywords", {
            setting_id: settingId,
            status_id: statusId,
            newValue: newValue,
          });
          handleFetchLanguage()
        } catch (error) {
          console.error("Translation error:", error);
        }
      };

      // To fetch the value after translateAll ============
    
      useEffect(() => {
        if (Data?.results && Object.keys(valueMap).length === 0) {
          const updatedMap = {};
          Data.results.forEach((item) => {
            updatedMap[item.setting_id] = item.Translation;
          });
          setValueMap(updatedMap);
        }
      }, [Data?.results]);
      console.log("Language Translate @@@@",Data?.results)


      

    // handle Update 1 Keyword 
    const handleUpdateOneKeyword = (settingId) => {
        const newValue = valueMap[settingId] ?? "";
        try{
            postData("/editKeyword",{
                setting_id: settingId,
                status_id: statusId,
                newValue: newValue,
            });
            toast.success("Value updated Successfully!")

            handleFetchLanguage()
        } catch(error) {
            
        }
    }


  const handleTranslateAllKeyword = async () => {
    try {
      // Call translate API
      await postData("/translateAllKeywords", { status_id: statusId });
      toast.success("All keywords translated!");
  
      // After translation, update the valueMap with translated values
      const updatedMap = {};
      data?.results?.forEach((item) => {
        updatedMap[item.setting_id] = item.Translation;
      });
      setValueMap(updatedMap);
  
      // Fetch the language data again after updating
      handleFetchLanguage();
    } catch (error) {
      toast.error("Translation failed.");
    }
  };
  
  

    // 

    const LanguageData = Data?.results
    console.log("Lan Data !!!",valueMap)
    return(
        <>
          <div className="light:mb-10 xl:pl-72 dark:bg-primary">
          <Searchbar />

          <div className="px-4 xl:px-6">
          {/* Navigation Path */}
          <div className="items-center justify-between my-3 md:flex">
            <div className="flex items-center gap-2">
                <Link to="/dashboard"><h3 className="text-[#3A3A3A] font-poppins text-base font-semibold dark:text-darkText">Dashboard</h3></Link>
                <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
                <h3 className="text-[#858585] font-poppins text-base">Language Setting</h3>
            </div>

            {/* Translate All button */}
            <button className='flex gap-1.5 place-items-center mt-2 md:mt-0 px-6 py-2 text-sm font-poppins font-medium text-[#FFFFFF] rounded-md bg-button-gradient'
            onClick={handleTranslateAllKeyword}>
                Translate All
            </button>
         </div>

         {/* Table Header */}
         {/* <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg overflow-hidden mt-8 mx-6"> */}
         <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg mt-8 overflow-x-auto w-full">
      <div className='xl:overflow-x-auto lg:overflow-x-auto 2xl:overflow-hidden min-w-[1200px] '>
      <div className='min-w-max'> 
  {/* Table Header */}
  <div className="flex px-4 py-3 pl-16 text-left border-b dark:border-b-[#1F1F1F] bg-header1 dark:bg-darkHeader">
    {/* Setting ID */}
    <div className="w-[15%] text-[#666666] font-poppins font-semibold text-sm">SETTING ID</div>
    {/* Key */}
    <div className="w-[40%] text-[#666666] font-poppins font-semibold text-sm flex gap-2">KEY </div>

    {/* Value */}
    <div className='w-[40%] text-[#666666] font-poppins font-semibold text-sm flex gap-2'> VALUE </div>

    {/* Auto translate */}
    <div className="w-[15%] text-[#666666] font-poppins font-semibold text-sm flex gap-2">AUTO TRANSLATE</div>

    {/* Update */}
    <div className="w-[8%] text-[#666666] font-poppins font-semibold text-sm flex gap-2">UPDATE</div>
  </div>

  {/* Data Rows */}
  {loading ? (<>
   <div className='flex justify-center py-60'><img src={Loader} alt="loader" height={50} width={50}/></div>
  </>) : 
  
  (<>
    {LanguageData?.map((language, index) => (
    <div className={`${index % 2 === 0 ? 'bg-[#FFFFFF] dark:bg-primary' : 'bg-[#F5F6F7] dark:bg-primary'} flex items-center px-4 py-3 sm:pl-16 pl-4 border-b dark:border-b-[#1F1F1F] last:border-0`}>
      {/* Setting ID */}
      <div className="w-[15%] text-[#000000] dark:text-darkText font-poppins text-sm">{language.setting_id}</div>

      {/* Key */}
      <div className="w-[40%]">
        <h2 className="font-poppins text-sm border border-[#E5E7EB] text-[#000000] dark:text-tableDarkLarge dark:border-[#1F1F1F] w-[80%] p-1 rounded-md pl-4">{language.key}</h2>
        {/* <input type="text" value={language.key} /> */}
      </div>

      {/* Value */}
      <div className="w-[40%] ">
<input
  value={valueMap[language.setting_id] ?? language.Translation}
  placeholder="Enter value"
  onChange={(e) =>
    setValueMap((prev) => ({
      ...prev,
      [language.setting_id]: e.target.value,
    }))
  }
  className="border border-[#452B7A] text-[#000000] dark:border-[#1F1F1F] font-poppins dark:text-tableDarkLarge bg-transparent border-opacity-10 rounded px-2 py-1 w-[80%] text-sm focus:outline-none focus:ring-1 focus:ring-[#452B7A]"
/>

</div>

      {/* Auto Translate */}

      <div className="w-[15%]">
  <button
    onClick={() => handleTranslateOneKeyword(language.setting_id)}
    className="border border-[#452B7A] bg-[#593A99] dark:text-darkText font-poppins text-[#ffffff] text-xs rounded-md px-6 py-1.5"
  >
    Translate
  </button>
</div>

      {/* Update */}
      <div className="w-[8%] text-[#3A3A3A] dark:text-tableDarkLarge font-poppins text-sm">

        {/** Check if value has changed */}
{(() => {
  const currentVal = valueMap[language.setting_id] ?? "";
  const isUnchanged = currentVal === language.Translation;
  return (
    <button
      className={`border border-[#FE2A40] bg-[#D23C3C] font-poppins dark:text-darkText text-[#FFFFFF] text-xs rounded-md px-6 py-1.5 transition-opacity ${isUnchanged ? "opacity-50 cursor-not-allowed" : "opacity-100"}`}
      onClick={() => !isUnchanged && handleUpdateOneKeyword(language.setting_id)}
      disabled={isUnchanged}>
      Update
    </button>
  );
})()}

      </div>
    </div>
  ))}
  </>)}

  
  
      {/* Pagination Buttons */}
  <div className="flex justify-between px-10 py-6 bg-white dark:bg-primary">
  {/* Results Count */}
  <div className="relative flex gap-2 place-items-center" ref={dropdownRef}>
    {/* Dropdown Button */}
    <div
      className="border border-[#9C9C9C] dark:border-[#1F1F1F] bg-[#edeff166]  dark:bg-primary rounded-xl flex gap-2 items-center px-3 py-1 cursor-pointer relative"
      onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
      <p className="text-[#00162e] dark:text-[#ffffff] font-poppins">{selectedValue}</p>
      <button>
        <img src={Arrow} className="w-4 h-4" />
      </button>
    </div>
  
    {/* Dropdown Menu - Positioned Above */}
    {isDropdownOpen && (
      <div className="absolute left-0 z-50 mb-2 bg-white dark:border-[#1F1F1F] border border-gray-300 rounded-lg shadow-lg dark:bg-primary bottom-full w-max">
        {options.map((option) => (
          <p
            key={option}
            className="px-4 py-2 text-sm cursor-pointer dark:text-darkText dark:hover:bg-slate-700 hover:bg-gray-200"
            onClick={() => handleSelect(option)}>
            {option}
          </p>
        ))}
      </div>
    )}
  
    {/* Results Text */}
    <p className="text-[#333333] font-poppins text-sm dark:text-gray-600">
      Showing {" "} <span className="font-semibold text-[#000000] dark:text-darkText text-sm">{pagination?.pageSize}</span>{" "}  results
    </p>
  </div>
  
      {/* Pagination Buttons */}
  
      <ul className="inline-flex items-center space-x-1 rtl:space-x-reverse">
  {/* Prev */}
  <li>
    <button
      type="button"
      disabled={currentPage === 1}
      onClick={() => setActivePage(currentPage - 1)}
      // className="flex justify-center font-semibold p-2 rounded-full transition bg-white-light text-dark hover:text-white hover:bg-primary dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary"
      className={`text-[#000000] text-sm dark:text-darkText font-poppins px-3 py-1 rounded-full transition-all duration-200 
        ${activePage === 1 ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-200 dark:hover:bg-slate-700"}`}
    >
      Previous
    </button>
  </li>

  {/* Pages */}
 {/* Page Number Buttons */}
{Array.from({ length: 5 }, (_, i) => {
  const startPage = Math.max(1, Math.min(activePage - 2, lastPage - 4));
  const pageNum = startPage + i;

  return pageNum <= lastPage ? (
    <button
      key={pageNum}
      onClick={() => setActivePage(pageNum)}
      className={`text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
        ${activePage === pageNum ? "text-white bg-button-gradient" : "text-black dark:text-darkText hover:bg-gray-200 dark:hover:bg-slate-700"}`}
        
    >
      {pageNum}
    </button>
  ) : null;
})}

{lastPage > 5 && activePage < lastPage - 2 && (
    <>
      <span className="px-2 dark:text-darkText">...</span>
      <button
        onClick={() => setActivePage(lastPage)}

        className={`text-sm font-poppins px-3 py-1 rounded-full transition-all duration-200 
          ${activePage === lastPage ? "text-white bg-button-gradient" : "text-black dark:text-darkText hover:bg-gray-200 dark:hover:bg-slate-700 dark:hover-none"}`}
        
      >
        {lastPage}
      </button>
    </>
  )}


  {/* Next */}
  <li>
    <button
      type="button"
      disabled={currentPage === totalPages}
      onClick={() => setActivePage(currentPage + 1)}
      // className="flex justify-center font-semibold p-2 rounded-full transition bg-white-light text-dark hover:text-white hover:bg-primary dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary"
      className={`text-[#000000] text-sm dark:text-darkText font-poppins px-3 py-1 rounded-full transition-all duration-200 
        ${activePage === 1 ? "opacity-50 cursor-not-allowed" : "hover:bg-gray-200 dark:hover:bg-slate-700"}`}
    >
      Next
    </button>
  </li>
</ul>

  
    </div>
    
 
  </div>
  </div> 
         </div>

         </div>

          </div>
        </>
    )
}

export default Translate;

