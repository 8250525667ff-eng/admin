import React,{useState,useEffect,useRef} from 'react';
import Search from '../../assets/search.png';
import Searchbar from '../../components/Search';
import { Link, useNavigate } from 'react-router-dom';
import useApiPost from '../hooks/postData';
import Edit from '../../assets/edit.png'
import AddLanguage from './AddLanguageDialog'
import EditLanguage from './EditLanguageDialog'
import Add from '../../assets/add.png'
import Translate from '../../assets/translate.png'
import {useGetAllLanguageQuery} from '../../store/api/GetAllLanguage'
import Cookies from 'js-cookie'
import { useSelector } from 'react-redux';
import NoData from '../../assets/NoData.png'
import Loader from '../../assets/Loader.gif'

function LanguageList() {
  // Sample data for posts
  const [StatusID,setStatusID] = useState("")
  
  const { data, error, isLoading, refetch,postData } = useApiPost()
  const token = Cookies.get("Snapta_Admin_Token")

  const {data:LanguageData,refetch:AllLanguageRefetch} = useGetAllLanguageQuery({token:token})
  const LanguageList = LanguageData?.languages
  console.log("Language !!!",LanguageData?.languages)

const [toggleStates, setToggleStates] = useState({});
const [toggleDefaultStates, setToggleDefaultStates] = useState({});

const handleStatusToggle = (statusId) => {
  setToggleStates((prev) => {
    const newStatus = !prev[statusId];
    postData("/updateStatus",{status_id:statusId,status:newStatus ? 1 : 0})
    AllLanguageRefetch()
    return { ...prev, [statusId]: newStatus };
  });
};

const handleDefaultToggle = (statusId) => {
  setToggleDefaultStates((prev) => {
    const newDefault = !prev[statusId];
    // You can optionally make an API call here to update default status
    postData('/updateStatus', { status_id: statusId, default_status: newDefault ? 1 : 0 })
    AllLanguageRefetch()
    return { ...prev, [statusId]: newDefault };
  });
};

useEffect(() => {
  if (LanguageList && LanguageList.length > 0) {
    const initialStatusStates = {};
    const initialDefaultStates = {};
    LanguageList.forEach((lang) => {
      initialStatusStates[lang.status_id] = lang.status === 1;
      initialDefaultStates[lang.status_id] = lang.default_status === 1;
    });
    setToggleStates(initialStatusStates);
    setToggleDefaultStates(initialDefaultStates);
  }
}, [LanguageList]);
   
  //  To open Translate page all key value 
  const navigate = useNavigate()
  
  const openTranslate = (statusId) => {
    navigate(`/language-list/${statusId}`)
  }

  // To open Dialog 
  const [open,setOpen] = useState(false)
  const [LanguageName,setLanguageName] = useState("")
  const handleOpen = (statusid,LanguageName) => 
    {  
      setStatusID(statusid)
      setLanguageName(LanguageName)
      setOpen(true)
    }
  const handleClose = () => {
    setOpen(false)
  }

  // to open add language dialog 
  const [openAddLanguage,setOpenAddLanguage] = useState(false)
  const handleOpenAdd = () => {
    setOpenAddLanguage(true)
  }

  const handleCloseAdd = () => {
    setOpenAddLanguage(false)
    AllLanguageRefetch()
  }

  console.log("Status !!!",LanguageName)

  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);


  return (
    <>
    {/* <div className="mb-10 pl-72"> */}
    <div className={`light:mb-10 dark:bg-primary ${isSidebarOpen? "xl:pl-20" : "xl:pl-72"}`}>
      <Searchbar />
      <div className='px-4 xl:px-6'>

      {/* Title */}
      <div className="flex justify-between border-t-[#F2F2F2] py-3">
        <h2 className="text-[#000000] font-poppins text-xl font-semibold pt-3 dark:text-darkText">Language List</h2>
        {/* Add Language Button */}
        <button className='flex gap-1.5 place-items-center px-4 text-sm font-poppins font-medium text-[#FFFFFF] bg-button-gradient rounded-xl' onClick={handleOpenAdd}>
          <img src={Add} className='w-4 h-4' />
          <p>Add Language</p>
        </button>
      </div>

      {/* Navigation Path */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Link to="/dashboard"><h3 className="text-[#3A3A3A] font-poppins text-base font-semibold dark:text-darkText">Dashboard</h3></Link>
          <div className="rounded-full w-1 h-1 bg-[#E0E0E0]"></div>
          <h3 className="text-[#858585] font-poppins text-base">Language List</h3>
        </div>
        {/* Search by username */}
        <div className="relative">
          <div className="absolute flex items-center p-2 transform -translate-y-1/2 left-2 top-1/2">
            <img src={Search} alt="Search" className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Header Bar */}
      {/* <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] bg-[#F1F1F1] rounded-lg overflow-hidden mt-8 mx-6"> */}
      <div className="border border-[#E3E3E3] dark:border-[#1F1F1F] rounded-lg mt-8 overflow-x-auto w-full">
      <div className='xl:overflow-x-auto lg:overflow-x-auto 2xl:overflow-hidden min-w-[1200px] '>
      <div className='min-w-max'> 
  {/* Table Header */}
  <div className="flex px-4 py-3 pl-16 text-left border-b dark:border-b-[#1F1F1F] dark:bg-darkHeader bg-header1">
    <div className="w-[15%] text-headerText font-poppins text-sm font-semibold">S.L </div>
    {/* Language */}
    <div className="w-[20%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">LANGUAGE </div>

    {/* Country */}
    <div className='w-[20%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold'> COUNTRY </div>
    
    {/* Status */}
    <div className="w-[20%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">STATUS</div>
    {/* Default */}
    <div className="w-[20%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">DEFAULT</div>
    {/* Actions */}
    <div className="w-[15%] text-headerText font-poppins text-sm flex place-items-center gap-2 font-semibold">ACTIONS </div>
  </div>

  {/* Data Rows */}
  {isLoading ? (<>
   <div className='flex justify-center py-60'><img src={Loader} alt="loader" height={50} width={50}/></div>
  </>) : (<>
    {LanguageList?.length > 0 ? 
  
  (<>
   {LanguageList?.map((language, index) => (
    <div key={language.id} className={`${index % 2 === 0 ? 'bg-white dark:bg-primary' : 'bg-[#00162e0a] dark:bg-primary'} flex items-center px-4 py-3 dark:border-b-[#1f1f1f] pl-16 border-b last:border-0`}>

      {/* Serial Number */}
      <div className="w-[15%] text-[#000000] dark:text-darkText font-poppins text-sm">{index + 1}</div>

      {/* LANGUAGE */}
      <div className="w-[20%]">
        <p className='text-[#00162e] font-poppins dark:text-tableDarkLarge text-sm'>{language.language}</p>
      </div>

      {/* COUNTRY */}
      <div className='w-[20%]'>
        <div className='flex gap-2'>
            {/* <img src={Flag} className="object-cover w-6 h-6" /> */}
            <p className='text-sm dark:text-tableDarkLarge'>{language.country}</p>
        </div>
      </div>

      {/* STATUS */}
      {/* <div key={language.status_id} className="w-[20%]">
  <label className="flex items-center cursor-pointer select-none">
    <div className="relative">
      <input
        type="checkbox"
        checked={toggleStates[language.status_id]}
        onChange={() => handleCheckboxChange(language.status_id)}
        className="sr-only"
      />
      Toggle Background
      <div
        className={`block h-6 w-10 rounded-full border transition ${
          toggleStates[language.status] ? "bg-header border-header" : "border-header"
        }`}></div>

      Toggle Dot
      <div
        className={`absolute h-4 w-4 rounded-full transition ${
          toggleStates[language.status]
            ? "right-1 top-1 bg-white"
            : "left-1 top-1 bg-header"
        }`}
      ></div>
    </div>
  </label>
</div> */}

<div className="w-[20%]">
  <label className="flex items-center cursor-pointer select-none">
    <div className="relative">
      <input
        type="checkbox"
        checked={toggleStates[language.status_id]}
        onChange={() => handleStatusToggle(language.status_id)}
        className="sr-only"
      />
      <div
        className={`block h-6 w-10 rounded-full border transition ${
          toggleStates[language.status_id] ? "bg-header border-header" : "border-header"
        }`}
      ></div>
      <div
        className={`absolute h-4 w-4 rounded-full transition ${
          toggleStates[language.status_id]
            ? "right-1 top-1 bg-white"
            : "left-1 top-1 bg-header"
        }`}
      ></div>
    </div>
  </label>
</div>


      {/* DEFAULT */}
      {/* <div key={language.status_id} className="w-[20%]">
  <label className="flex items-center cursor-pointer select-none">
    <div className="relative">
      <input
        type="checkbox"
        checked={toggleDefaultStates[language.status_id]}
        onChange={() => handleDefaultCheckboxChange(language.status_id)}
        className="sr-only"
      />
      Toggle Background
      <div
        className={`block h-6 w-10 rounded-full border transition ${
          toggleDefaultStates[language.default_status] ? "bg-header border-header" : "border-header"
        }`}></div>

      Toggle Dot
      <div
        className={`absolute h-4 w-4 rounded-full transition ${
          toggleDefaultStates[language.default_status]
            ? "right-1 top-1 bg-white"
            : "left-1 top-1 bg-header"
        }`}
      ></div>
    </div>
  </label>
</div> */}

<div className="w-[20%]">
  <label className="flex items-center cursor-pointer select-none">
    <div className="relative">
      <input
        type="checkbox"
        checked={toggleDefaultStates[language.status_id]}
        onChange={() => handleDefaultToggle(language.status_id)}
        className="sr-only"
      />
      <div
        className={`block h-6 w-10 rounded-full border transition ${
          toggleDefaultStates[language.status_id] ? "bg-header border-header" : "border-header"
        }`}
      ></div>
      <div
        className={`absolute h-4 w-4 rounded-full transition ${
          toggleDefaultStates[language.status_id]
            ? "right-1 top-1 bg-white"
            : "left-1 top-1 bg-header"
        }`}
      ></div>
    </div>
  </label>
</div>


      {/* ACTIONS */}
       <div className="w-[15%] flex gap-4">
          <button className="bg-[#D0CCE1] bg-opacity-[57%] rounded-full p-2" onClick={() => handleOpen(language.status_id,language.language)}>
              <img src={Edit} className="w-4 h-4" />
          </button>
          <button className="bg-[#F3E5E5] rounded-full p-2" onClick={() => openTranslate(language.status_id)}>
              <img src={Translate} className="w-4 h-4" />
          </button>
       </div>
    </div>
  ))}
  </>) : 
  
  (<>
   <div className='flex flex-col justify-center py-32 2xl:py-36 place-items-center'>
       <img src={NoData} alt="no data" className='w-96' />
       <h2 className='font-poppins text-[#000000] text-sm font-semibold'>Don't have any data to show</h2>
      </div>
  </>)}
  </>)}
 
  

  {/* Pagination and Results Count */}
  
      </div> 
      </div>
      </div>
      </div>
    </div>

    {open && 
    <EditLanguage open={open} handleClose={handleClose} statusID={StatusID} LanguageName={LanguageName} /> }

    {openAddLanguage && 
    <AddLanguage openAddLanguage={openAddLanguage} handleCloseAdd={handleCloseAdd} />}
    </>
  );
}

export default LanguageList;

