import React, { useState } from "react";
import Delete from '../../assets/delete.png';
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Cross from '../../assets/cross.png'
import '../../components/DialogBoxCustom.css'
import useApiPost from "../hooks/postData";
import toast from "react-hot-toast";
import { useGetAdminNotificationQuery } from "../../store/api/AdminNotificationList";
import Cookies from 'js-cookie'

function AddNotification({ open, handleClose, handleRefetch }) {

    const {data,error,postData} = useApiPost()
    const token = Cookies.get("Snapta_Admin_Token")
    const {data:AdminNotification,refetch} = useGetAdminNotificationQuery({token:token})
    const [title,setTitle] = useState("")
    const [message,setMessage] = useState("")
    const handlePushNotification = () => {
        try{
            const response = postData("/add_notification",{title:title,message:message})
            handleRefetch()
            handleClose()
            toast.success("Push Notification Done Successfully!")
            
        } catch(error){

        }
    }
    
  
    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="dialog" >
            <DialogTitle className="flex justify-center text-base dark:bg-primary font-bold text-[#000000] dark:text-darkText font-poppins bg-[#FFFFFF] shadow-lg light:rounded-lg">Push Notification</DialogTitle>
            {/* <img src={Cross} className="absolute w-8 h-8 cursor-pointer top-4 right-2" onClick={handleClose} /> */}
            <button onClick={handleClose} className="absolute text-2xl text-gray-600 dark:text-white top-2 right-3">
                 ×
            </button>
            <DialogContent className="flex flex-col light:mx-5 dark:bg-primary">
                {/* Delete Icon */}
                <h2 className="text-base font-poppins text-[#000000] pt-6 dark:text-darkText">Title</h2>
                <input type="text" placeholder="Enter Title"
                className="border border-opacity-gradient dark:bg-transparent dark:placeholder:text-tableDarkLarge dark:text-darkText dark:border-[#1F1F1F] rounded-lg w-full py-2 my-1 px-4 placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                onChange={(e) => setTitle(e.target.value)}/>
                
                <h2 className="text-base font-poppins text-[#000000] pt-6 dark:text-darkText">Description</h2>
                <textarea className="border border-opacity-gradient dark:bg-transparent dark:placeholder:text-tableDarkLarge dark:text-darkText dark:border-[#1F1F1F] rounded-lg w-full my-1 pt-2 px-4 min-h-[130px] resize-none placeholder:font-gilroy_regular placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-header"
                 placeholder="Write Description" onChange={(e) => setMessage(e.target.value)}/>
                 
                <div className="flex justify-center py-8">
                    <button className="px-20 py-3 font-medium text-white rounded-xl bg-button-gradient" 
                    onClick={handlePushNotification}>
                        Submit
                    </button>
                </div>
            </DialogContent>
    
        </Dialog>
    );
}

export default AddNotification;
