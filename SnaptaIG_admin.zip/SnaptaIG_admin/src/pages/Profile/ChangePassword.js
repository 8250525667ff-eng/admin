import React, { useState } from 'react'
import Lock from '../../assets/lock.png'
import Eye from '../../assets/profile_eye.png'
import Profile1 from '../../assets/Profile.png'
import Plus from '../../assets/Plus.png'
import useApiPost from '../hooks/postData'
import toast from 'react-hot-toast'
import { CiLock } from "react-icons/ci";
import { useGetDetailsQuery } from '../../store/api/GetProfileDetails'
import { LuLockKeyhole } from "react-icons/lu";
import Cookies from 'js-cookie'

function ChangePassword() 
{
  const {data,error,postData} = useApiPost()
  const [formData,setFormData] = useState({
    password:"",
    npassword:"",
    cpassword:""
  })
  const handleChangePassword = () => {
    try{
      const response = postData("/change_password",formData)
      toast.success("Password Changed Successfully!")
    } catch(error) {
      
    }
  }

  const token = Cookies.get("Snapta_Admin_Token")
   const {data:ProfileData,refetch} = useGetDetailsQuery({token:token})
    const Data = ProfileData?.user_data
  console.log("Form Data !!!",formData)

  


    return(
        <>
        <div>
          <div className='flex justify-center'>
            <div className='max-w-[1000px] w-full'>
              {/* All fields */}
              {/* Profile Image */}
            <div className="flex items-center justify-center w-full py-4">
              <div className="shadow-[9.3px_10.46px_64.96px_0px_rgba(0,0,0,0.2)] px-1 py-1 rounded-full">
                <div className="relative flex items-center justify-center w-24 h-24">
                  {/* User Image */}
                  <img src={Data?.profile_pic}  alt="User" className="absolute inset-0 w-24 h-24 m-auto rounded-full"/>
                </div>
              </div>
            </div>

            {/* Name */}
            <h2 className='flex justify-center pb-3 text-base font-semibold font-poppins dark:text-darkText'>{Data?.first_name} {Data?.last_name}</h2>
                        <div className='grid gap-3 px-10 py-4 md:gap-10 md:grid-cols-2'>
                            {/* Current Password */}
                       <div className="relative flex flex-col">
                        <label className="text-[#000000] font-poppins text-sm dark:text-darkText">Current Password<span className='text-sm text-red-600'>*</span></label>
                        <div className="relative">
                        <div className="absolute flex items-center justify-center p-3 transform -translate-y-1/2 rounded-lg bg-opacityGradient dark:bg-purple-300 left-2 top-1/2">
                        {/* style={{background:' linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)'}}> */}
                          <img src={Lock} alt="User" className="w-5 h-5"/>
                          {/* <LuLockKeyhole className='w-5 h-5 text-sidebarText' /> */}
                        </div>
                        <input type="text" className="border placeholder:text-darkText dark:bg-transparent dark:text-darkText dark:border-borderColor border-[#452B7A] border-opacity-10 rounded-lg w-full py-4 my-1 pl-16 placeholder:font-poppins placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-[#452B7A]"
                          placeholder="Enter Current Password"
                          required
                          autoComplete = "off"
                          autoCorrect="off"
                          spellCheck="false"
                          onChange={(e) =>  setFormData({...formData,password:e.target.value})}
                          value={formData.password}/>
                        </div>
                      </div>
            
                      {/* New Password */}
                      <div className="relative flex flex-col">
                        <label className="text-[#000000] font-poppins text-sm dark:text-darkText">New Password<span className='text-sm text-red-600'>*</span></label>
                        <div className="relative">
                        <div className="absolute flex items-center justify-center p-3 transform -translate-y-1/2 rounded-lg bg-opacityGradient dark:bg-purple-300 left-2 top-1/2">
                        {/* style={{background:' linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)'}}> */}
                          <img src={Lock} alt="User" className="w-5 h-5"/>
                          {/* <LuLockKeyhole className='w-5 h-5 text-sidebarText' /> */}

                        </div>
                        <input type="text" className="border placeholder:text-darkText border-[#452B7A] dark:bg-transparent dark:text-darkText dark:border-borderColor border-opacity-10 rounded-lg w-full py-4 my-1 pl-16 placeholder:font-poppins placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-[#452B7A]"
                          placeholder="Enter New Password"
                          required
                          autoComplete = "off"
                          autoCorrect="off"
                          spellCheck="false"
                          onChange={(e) => setFormData({...formData,npassword:e.target.value})}
                          value={formData.npassword}/>
                        </div>
                      </div>
                      </div>
            
                      {/* Confirm Password */}
                      <div className='grid gap-3 px-10 pb-4 md:gap-10 md:grid-cols-2'>
                      <div className="relative flex flex-col">
                        <label className="text-[#000000] font-poppins text-sm dark:text-darkText">Confirm Password<span className='text-sm text-red-600'>*</span></label>
                        <div className="relative">
                        <div className="absolute flex items-center justify-center p-3 transform -translate-y-1/2 rounded-lg bg-opacityGradient dark:bg-purple-300 left-2 top-1/2">
                        {/* style={{background:' linear-gradient(213deg, rgba(108, 71, 183, 0.1) -27.59%, rgba(52, 31, 96, 0.1) 105.15%)'}}> */}
                          <img src={Lock} alt="User" className="w-5 h-5"/>
                          {/* <LuLockKeyhole className='w-5 h-5 text-sidebarText' /> */}

                        </div>
                        <input type="text" className="border border-[#452B7A] placeholder:text-darkText dark:bg-transparent dark:text-darkText dark:border-borderColor border-opacity-10 rounded-lg w-full py-4 my-1 pl-16 placeholder:font-poppins placeholder:text-sm placeholder:text-[#000000] placeholder:opacity-50 bg-white focus:outline-none focus:ring-1 focus:ring-[#452B7A]"
                          placeholder="Enter Confirm Password"
                          required
                          autoComplete = "off"
                          autoCorrect="off"
                          spellCheck="false"
                          onChange={(e) => setFormData({...formData,cpassword:e.target.value})}
                          value={formData.cpassword}/>
                        </div>
                      </div>        
                      </div>

            
                      {/* Submit Button */}
                      <div className='flex justify-center py-8'>
                        <button className='text-base font-poppins text-[#FFFFFF] px-16 py-2 rounded-lg bg-button-gradient'
                         onClick={handleChangePassword}>
                             Submit
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
        </>
    )
}

export default ChangePassword