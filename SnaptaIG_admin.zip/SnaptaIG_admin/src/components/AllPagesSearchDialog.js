import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Search1 from '../assets/search.png';
import { useNavigate } from "react-router-dom";
import { useTheme } from "../context/ThemeProvider";
import { useGetDetailsQuery } from '../store/api/GetProfileDetails';
import Cookies from 'js-cookie';
import '../components/DialogBoxCustom.css';
import { RxCross2 } from "react-icons/rx";

const searchOptions = [
    { name: "Dashboard", path: "/dashboard" },
    { name: "User List", path: "/user-list" },
    { name: "Post List", path: "/post-list" },
    { name: "Reel List", path: "/reel-list" },
    { name: "User Report List", path: "/user-report-list" },
    { name: "Post Report List", path: "/post-report-list" },
    { name: "Reel Report List", path: "/reel-report-list" },
    { name: "Profile", path: "/profile" },
    { name: "Stories List", path: "/stories-list" },
    { name: "Push Notification", path: "/push-notification" },
    { name: "Hashtag List", path: "/hashtag-list"},
    { name: "Language List", path: "/language-list"},
    { name: "Block List", path:'/block-list'},
    { name: "Avatar List", path:'/avtar-list'},
    { name: 'Countrywise Users', path: '/country-wise-users'},
    { name: "CMS Pages", path:"/cms" },
    { name: "Profile" , path: '/profile' },
    { name: "Settings" , path: '/settings'}
];

function SearchOptions({ open, handleClose }) {
    const [search, setSearch] = useState("");
    const navigate = useNavigate();

    const token = Cookies.get("Snapta_Admin_Token");
    const { data: ProfileData } = useGetDetailsQuery({ token });
    const profile = ProfileData?.user_data;

    const { theme } = useTheme();

    const filteredOptions = search
        ? searchOptions.filter(option =>
            option.name.toLowerCase().includes(search.toLowerCase())
        )
        : searchOptions; // show all when empty

    return (
        <Dialog open={open} onClose={handleClose} fullWidth className="hashtag-dialog">
            {/* Cross Button - Top Right */}
            {/* <img
                src={Cross}
                alt="close"
                className="absolute z-50 cursor-pointer w-7 h-7 top-4 right-4 sm:w-8 sm:h-8"
                onClick={handleClose}
            /> */}
            
            <RxCross2  className="absolute z-50 w-5 h-5 top-2 right-4 dark:text-white" onClick={handleClose}/>

            <DialogContent className="flex flex-col light:mx-5 dark:bg-primary">
                {/* Search Bar */}
                <div className="relative mt-4 mb-3">
                    <div className="absolute transform -translate-y-1/2 left-3 top-1/2">
                        <img src={Search1} alt="Search" className="w-5 h-5" />
                    </div>

                    <input
                        type="text"
                        placeholder="Search..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="w-full border border-gray-300 bg-[#f9f9f9] dark:bg-[#222] dark:text-white pl-10 pr-3 py-2 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-400"
                    />
                </div>

                {/* Option List */}
                <div className="max-h-[400px] overflow-y-auto  rounded-lg">
                    {filteredOptions.map(option => (
                        <p
                            key={option.name}
                            onClick={() => {
                                navigate(option.path);
                                handleClose();
                            }}
                            className="px-4 py-2 cursor-pointer dark:text-darkText font-poppins light:hover:bg-gray-100 dark:hover:bg-[#333] text-sm border-b last:border-b-0"
                        >
                            {option.name}
                        </p>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    );
}

export default SearchOptions;
