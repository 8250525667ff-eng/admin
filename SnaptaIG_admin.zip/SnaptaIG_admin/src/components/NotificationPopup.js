import React,{useEffect,useRef} from 'react'
import Snapta from '../assets/SnaptaLogo.png'
import { Link, useNavigate } from 'react-router-dom'
import Cookies from 'js-cookie'
import { useGetAllNotificationQuery } from '../store/api/AllNotificationList'
import useApiPost from '../pages/hooks/postData'
import Tick from '../assets/not_tick.png'

function Notification() {
  const token = Cookies.get("Snapta_Admin_Token")
  const { data: NotificationData, refetch } = useGetAllNotificationQuery({ token })
  const NotificationList = NotificationData?.detail
  const navigate = useNavigate()
  const {data,error,postData} = useApiPost()

  console.log("Notification !!!",NotificationList)
 

  const handleReadNotification = () => {
    try{
        const response = postData("/all_user_notification_list",{read_status:1})
        refetch()
    } catch(error){

    }
  }

  const handleRedirect = (title) => {
    switch (title) {
      case 'User Report':
        navigate('/user-report-list')
        break
      case 'Post Report':
        navigate('/post-report-list')
        break
      case 'Reel Report':
        navigate('/reel-report-list')
        break
      case 'User Blocked':
        navigate('/block-list')
        break
      default:
        break
    }
  }

  return (
    <div className='md:w-[450px] w-[350px] bg-white shadow-lg dark:bg-primary rounded-xl'>
      <div className='flex justify-between px-4 py-4 border-b place-items-center border-[#F2F2F2] dark:border-[#1F1F1F]'>
        <h2 className='text-base font-semibold font-poppins dark:text-darkText'>
          Notification ({NotificationData?.pending_notification})
        </h2>
        <p className='text-[#848484] font-poppins text-xs underline cursor-pointer' onClick={handleReadNotification}>
          Mark all as read
        </p>
      </div>

      {NotificationList?.slice(0,5).map((notification) => (
        <div
          key={notification.not_id}
          onClick={() => handleRedirect(notification.title)}
          className={`cursor-pointer flex justify-between gap-4 hover:bg-gray-100 dark:hover:bg-[#1F1F1F] px-4 py-2 border-b dark:border-[#1F1F1F] place-items-center `}
        >
          <div className='flex gap-4 place-items-center'>
            {/* Logo */}
            <div className='border rounded-lg border-opacityGradient'>
              <img src={Snapta} className='p-2 w-11 h-11' />
            </div>
            {/* message and time */}
            <div className='flex flex-col'>
            <p className='text-sm font-poppins text-[#000000] dark:text-darkText'>
             
    {notification.message[0].toUpperCase() + notification.message.slice(1)}

            </p>
          <p className='font-poppins text-[#ADADAD] text-xs'>{notification.time_ago}</p>
          </div>
          </div>

          {/* viewed or not */}
          <div>
            {notification.is_view === 0 ? 
            <> <div className='w-2 h-2 rounded-full bg-[#452B7A]'>
                 
                </div> </> : 
            
            <>
             <div className='rounded-full border border-[#DBDBDB]'>
                <img src={Tick} className='w-4 h-4'/>
             </div>
            </>}
          </div>
        </div>
      ))}

      <div className='px-5 py-4 text-center border-t border-[#F2F2F2] dark:border-[#1F1F1F]'>
        <Link to="/notification-list">
          <button className='flex gap-1.5 py-2 w-full justify-center px-4 text-sm font-poppins font-medium text-[#FFFFFF] rounded-md bg-button-gradient' onClick={handleReadNotification}>
            View All
          </button>
        </Link>                           
      </div>
    </div>
  )
}

export default Notification




