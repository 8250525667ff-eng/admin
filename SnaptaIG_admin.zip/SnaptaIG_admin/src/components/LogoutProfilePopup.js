import React, { useState } from "react";
import { useGetDetailsQuery } from "../store/api/GetProfileDetails";
import Cookies from 'js-cookie'
import { Link } from "react-router-dom";
import LogoutDialog from '../pages/Logout/LogoutPopup';

function LogoutProfilePopup({onLogoutClick}) 
{
    const token = Cookies.get("Snapta_Admin_Token")
    const {data:ProfileData,error,refetch} = useGetDetailsQuery({token:token})
    const profile = ProfileData?.user_data

    return(
        <>
         <div className='md:w-[350px] w-[400px] border dark:border-[#1F1F1F] bg-white shadow-lg dark:bg-primary rounded-xl'>
            <div className="w-full px-6 py-4 border-b dark:border-b-[#1F1F1F]">
            {/* Profile Details */}
            <div className="flex gap-3 place-items-center">
                {/* Profile pic */}
                <div className="rounded-full">
                    <img src={profile?.profile_pic} className="w-12 h-12 rounded-full"/>
                </div>

                {/* name and email */}
                <div className="flex flex-col">
                    <h3 className="text-base font-semibold font-poppins dark:text-darkText">{profile?.first_name} {profile?.last_name}</h3>
                    <p className="text-sm font-poppins dark:text-darkText">{profile?.email}</p>
                </div>
            </div>
           </div>

           {/* Profile Logout options */}
           <div className="flex flex-col gap-2 px-6 py-4">
             <Link to="/profile"><p className="cursor-pointer font-poppins dark:text-darkText">My Profile</p></Link>
             <p className="cursor-pointer font-poppins dark:text-darkText" onClick={() => onLogoutClick()}>Logout</p>
           </div>
         </div>
        </>
    )
}

export default LogoutProfilePopup;
