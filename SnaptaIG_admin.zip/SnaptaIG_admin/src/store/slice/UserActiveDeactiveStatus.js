// userStatusSlice.js

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  statusMap: {}, // { [userId]: "0" or "1" }
};

const userStatusSlice = createSlice({
  name: "userStatus",
  initialState,
  reducers: {
    updateUserStatus(state, action) {
      const { userId, status } = action.payload;
      state.statusMap[userId] = status;
    },
  },
});

export const { updateUserStatus } = userStatusSlice.actions;
export default userStatusSlice.reducer;
