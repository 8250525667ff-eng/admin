

import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const getAllLanguage = createApi({
  reducerPath: "getAllLanguage",
  baseQuery: fetchBaseQuery({
    baseUrl: process.env.REACT_APP_API_URL,
  }),
  endpoints: (builder) => ({
    getAllLanguage: builder.query({
      query: () => ({
        url: "listAllLanguages",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {}, // No token
      }),
    }),
  }),
});

export const { useGetAllLanguageQuery } = getAllLanguage;
