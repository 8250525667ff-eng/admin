import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Sidebar from "./pages/Sidebar/Sidebar";
import ProtectedRoute from "./pages/ProtectedRoute";
import { ThemeProvider } from "./context/ThemeProvider";
import { AuthProvider, useAuth } from "./context/AuthContext";

// 2f25248f-237a-458a-a425-6983e4a99caa

// Pages
import SignIn from "./pages/SignIn/SignIn";
import Dashboard from "./pages/Dashboard/Dashboard";
import UserList from "./pages/UserList/UserList";
import PostList from "./pages/PostList/PostList";
import ReelList from "./pages/ReelList/ReelList";
import StoriesList from "./pages/StoriesList/StoriesList";
import CountryWiseUserList from "./pages/CountryWiseUsersList/CountryWiseUsersList";
import UserReportList from "./pages/ReportList/UserReportList";
import PostReportList from "./pages/ReportList/PostReportList";
import ReelReportList from "./pages/ReportList/ReelReportList";
import HashtagList from "./pages/HashtagList/HashtagList";
import LanguageList from "./pages/LanguageList/LanguageList";
import LanguageTranslate from "./pages/LanguageList/languageTranslate";
import NotificationList from "./pages/Notification/NotificationList";
import PushNotification from "./pages/Notification/PushNotification";
import BlockList from "./pages/BlockList/BlockList";
import AvatarList from "./pages/AvatarList/AvatarList";
import CMS from "./pages/CMSPages/PrivacyPolicy";
import Profile from "./pages/Profile/Profile";
import Settings from "./pages/Settings/Settings";
import UserProfile from "./pages/UserProfile/Userprofile";

// Installation Pages
import Page1 from "./pages/SoftwareInstallationProcess/Page1";
import Page2 from "./pages/SoftwareInstallationProcess/Page2";
import Page3 from "./pages/SoftwareInstallationProcess/Page3";
import Page4 from "./pages/SoftwareInstallationProcess/Page4";
import Page5 from './pages/SoftwareInstallationProcess/Page5';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <ThemeProvider>
          <Toaster position="top-center" reverseOrder={false} />
          <MainLayout />
        </ThemeProvider>
      </BrowserRouter>
    </AuthProvider>
  );
}

function MainLayout() {
  const location = useLocation();
  const { authStatus } = useAuth();

  const hideSidebarRoutes = [
    "/signin",
    "/snapta-install-1",
    "/snapta-install-2",
    "/snapta-install-3",
    "/snapta-install-4",
    "/snapta-install-5",
  ];

  const hideSidebar = hideSidebarRoutes.some((route) =>
    location.pathname.startsWith(route)
  );

  console.log("Auth Status 123@@@",authStatus)

  if(authStatus === "loading")
  {
    return(
      <>
      <div className="flex items-center justify-center py-48 place-items-center">
        <p className="font-poppins text-[#000000]">Loading...</p>
      </div>
      </>
    )
  }

  return (
    <div className="min-h-screen xl:flex dark:bg-primary">
      {!hideSidebar && (
        <div className="hidden xl:block">
          <Sidebar />
        </div>
      )}

      <div className="xl:flex-1">
        

<Routes>
  {authStatus === "not_found" || sessionStorage.getItem("show_varification_steps") ? (
    <>
      {/* Installation pages for first-time setup */}
      <Route path="/snapta-install-1" element={<Page1 />} />
      <Route path="/snapta-install-2" element={<Page2 />} />
      <Route path="/snapta-install-3" element={<Page3 />} />
      <Route path="/snapta-install-4" element={<Page4 />} />
      <Route path="/snapta-install-5" element={<Page5 />} />
      {/* Redirect any other route to install page */}
      <Route path="*" element={<Navigate to="/snapta-install-1" replace />} />
    </>
  ) : (
    <>
      {/* Sign In Page */}
      <Route path="/signin" element={<SignIn />} />

      {/* Protected Pages */}
      <Route element={<ProtectedRoute isAuthenticated={authStatus === "valid"} />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/user-list" element={<UserList />} />
        <Route path="/post-list" element={<PostList />} />
        <Route path="/reel-list" element={<ReelList />} />
        <Route path="/stories-list" element={<StoriesList />} />
        <Route path="/country-wise-users" element={<CountryWiseUserList />} />
        <Route path="/user-report-list" element={<UserReportList />} />
        <Route path="/post-report-list" element={<PostReportList />} />
        <Route path="/reel-report-list" element={<ReelReportList />} />
        <Route path="/hashtag-list" element={<HashtagList />} />
        <Route path="/language-list" element={<LanguageList />} />
        <Route path="/language-list/:statusId" element={<LanguageTranslate />} />
        <Route path="/notification-list" element={<NotificationList />} />
        <Route path="/push-notification" element={<PushNotification />} />
        <Route path="/block-list" element={<BlockList />} />
        <Route path="/avatar-list" element={<AvatarList />} />
        <Route path="/cms" element={<CMS />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/:source/user-profile" element={<UserProfile />} />
      </Route>

      {/* Optional: Fallback for unknown routes */}
      <Route path="/" element={<Navigate to="/signin" replace/>} />
      <Route path="*" element={<Navigate to="/signin" replace />} />
    </>
  )}
</Routes>
      </div>
    </div>
  );
}



